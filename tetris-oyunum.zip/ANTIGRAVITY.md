# VOCİ Tetris → Android APK (Google Antigravity)

Bu depo **çalışan bir web oyunu** + **hazır Android WebView sarmalayıcısı** içerir.
Google Antigravity bu dosyayı okuyup imzalı/imzasız APK üretebilir.

## Antigravity’ye yapıştırılacak komut

```
Bu klasör VOCİ Tetris. Web oyunu src/ altında.
Android sarmalayıcı android/ altında (WebView, dosya seçici, tam ekran).

Yapman gerekenler:
1) npm install && npm run build
2) dist/index.html dosyasını android/app/src/main/assets/index.html olarak kopyala
3) android/ için Gradle wrapper yoksa oluştur (gradle wrapper)
4) cd android && ./gradlew assembleDebug
5) Çıkan APK yolunu ver:
   android/app/build/outputs/apk/debug/app-debug.apk

Uygulama kimliği: tr.com.voci.tetris
Ad: VOCİ Tetris
minSdk 24, targetSdk 35
Oyun dokunmatik ve PWA uyumlu; WebView’de JS, DOM storage, medya jesti kapalı, dosya yükleme açık olmalı.
```

## Elle derleme

```bash
npm install
npm run build
cp dist/index.html android/app/src/main/assets/index.html
cd android
./gradlew assembleDebug
```

APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Notlar

- Oyun tek dosyalık HTML üretir (`vite-plugin-singlefile`) — WebView için idealdir.
- Telefon/tablet arayüzü `100dvh` içine sığar; altta dokunmatik pad vardır.
- Kayıt yükleme Android’de sistem dosya seçicisini açar (`onShowFileChooser`).
- Müzik ilk dokunuşta açılır.
