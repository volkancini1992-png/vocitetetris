export const APP_ICON = "https://i.ibb.co/Zzg6wSJy/iconvocitetris.png";
export const SPLASH_ART = "https://i.ibb.co/TMN6mZ6h/3d537948-e67f-46cd-aa90-819e735993e9.png";
