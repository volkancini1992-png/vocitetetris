import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useTetris } from "./hooks/useTetris";
import { Board } from "./components/Board";
import { Overlay } from "./components/Panels";
import { TopHud } from "./components/TopHud";
import { DeveloperFooter } from "./components/Brand";
import { SavesPanel } from "./components/SavesPanel";
import { GameMenu } from "./components/GameMenu";
import { Splash } from "./components/Splash";
import { AchieveScreen, LeadScreen, SettingsScreen, unlockAch } from "./components/ExtraScreens";
import { audio } from "./lib/audio";
import bgImage from "./assets/bg.jpg?inline";

export default function App() {
  const game = useTetris();
  const s = game.state;
  const hudRef = useRef<HTMLDivElement>(null);
  const footRef = useRef<HTMLDivElement>(null);
  const [music, setMusic] = useState(true);
  const [sfx, setSfx] = useState(true);
  const [inset, setInset] = useState({ top: 96, bottom: 32 });
  const [savesOpen, setSavesOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [extra, setExtra] = useState<null | "lead" | "ach" | "set">(null);

  useEffect(() => {
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";
    document.body.style.position = "fixed";
    document.body.style.inset = "0";
    document.body.style.width = "100%";
    document.body.style.height = "100%";
    const boot = () => audio.unlock();
    window.addEventListener("pointerdown", boot, { once: true });
    return () => window.removeEventListener("pointerdown", boot);
  }, []);

  useLayoutEffect(() => {
    const measure = () => {
      const top = hudRef.current?.getBoundingClientRect().height ?? 96;
      const bottom = footRef.current?.getBoundingClientRect().height ?? 32;
      setInset({ top, bottom });
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (hudRef.current) ro.observe(hudRef.current);
    if (footRef.current) ro.observe(footRef.current);
    window.addEventListener("resize", measure);
    window.addEventListener("orientationchange", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
      window.removeEventListener("orientationchange", measure);
    };
  }, []);

  useEffect(() => {
    audio.setMusic(music);
    if (music && s.status === "playing") audio.startMusic(false);
    if (!music) audio.stopMusic();
  }, [music, s.status]);

  useEffect(() => audio.setSfx(sfx), [sfx]);

  const bonusReady = s.status === "playing" && !s.relocating && !!s.lastPlaced;

  return (
    <div
      className="overflow-hidden bg-[#020617] text-white"
      style={{ position: "fixed", inset: 0, width: "100vw", height: "100dvh" }}
    >
      <div className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-40" style={{ backgroundImage: `url(${bgImage})` }} />

      <div
        ref={hudRef}
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 10000,
          background: "#020617",
          paddingTop: "env(safe-area-inset-top)",
        }}
      >
        <TopHud
          score={s.score}
          level={s.level}
          queue={s.queue}
          undoLeft={s.bonusLeft}
          bombNeed={s.bombNeed}
          music={music}
          onUndo={game.undoLast}
          onMenu={() => setMenuOpen(true)}
          onMusic={() => {
            audio.unlock();
            setMusic((m) => !m);
          }}
          onPause={game.togglePause}
        />
      </div>

      <div
        style={{
          position: "fixed",
          top: inset.top,
          bottom: inset.bottom,
          left: 0,
          right: 0,
          zIndex: 1,
          overflow: "hidden",
          contain: "strict",
        }}
      >
        <Board
          board={s.board}
          current={s.status === "over" ? null : s.current}
          clearing={s.clearing}
          dim={s.status !== "playing"}
          lastPlaced={s.lastPlaced}
          relocating={s.relocating}
          bonusReady={bonusReady}
          onPick={game.beginRelocate}
          onDrag={game.moveRelocate}
          onDrop={game.endRelocate}
          onOut={game.hoverOut}
          onSwipe={(d) => game.move(d)}
          onSoft={game.softDrop}
          onRotate={game.rotateCW}
          onHard={game.hardDrop}
          onHold={game.setHeld}
          bomb={s.bomb}
          bombPick={s.bombPick}
          boom={s.boom}
          onBomb={game.tapBomb}
          onRow={game.tapRow}
        />
        <Overlay
          status={s.status}
          score={s.score}
          level={s.level}
          lines={s.lines}
          best={s.best}
          onStart={() => {
            audio.unlock();
            game.start();
          }}
          onResume={game.togglePause}
          onLoad={() => setSavesOpen(true)}
        />
        {s.toast && (
          <div className="pointer-events-none absolute inset-x-0 top-1/3 z-40 text-center">
            <div className="animate-[pop_1.1s_ease-out_forwards] font-mono text-lg font-black text-amber-200">
              {s.toast.text}
            </div>
          </div>
        )}
      </div>

      <div
        ref={footRef}
        style={{
          position: "fixed",
          bottom: 0,
          left: 0,
          right: 0,
          zIndex: 10000,
          background: "#020617",
          paddingBottom: "env(safe-area-inset-bottom)",
        }}
      >
        <DeveloperFooter />
      </div>

      <GameMenu
        open={menuOpen}
        status={s.status}
        music={music}
        sfx={sfx}
        onClose={() => setMenuOpen(false)}
        onPause={() => {
          game.togglePause();
          setMenuOpen(false);
        }}
        onRestart={() => {
          game.start();
          setMenuOpen(false);
        }}
        onSave={() => {
          game.saveGame();
          setMenuOpen(false);
        }}
        onSaves={() => {
          setMenuOpen(false);
          setSavesOpen(true);
        }}
        onMusic={() => {
          audio.unlock();
          setMusic((m) => !m);
        }}
        onSfx={() => {
          audio.unlock();
          setSfx((v) => !v);
        }}
        onQuit={() => {
          game.quit();
          setMenuOpen(false);
        }}
      />
      {s.status === "ready" && extra === null && (
        <Splash
          onPlay={() => {
            unlockAch("play");
            audio.unlock();
            game.start();
          }}
          onLead={() => setExtra("lead")}
          onAchieve={() => setExtra("ach")}
          onSettings={() => setExtra("set")}
        />
      )}
      {extra === "lead" && <LeadScreen onClose={() => setExtra(null)} />}
      {extra === "ach" && <AchieveScreen onClose={() => setExtra(null)} />}
      {extra === "set" && (
        <SettingsScreen
          music={music}
          sfx={sfx}
          onMusic={() => {
            audio.unlock();
            setMusic((m) => !m);
          }}
          onSfx={() => {
            audio.unlock();
            setSfx((v) => !v);
          }}
          onClose={() => setExtra(null)}
        />
      )}
      <SavesPanel
        open={savesOpen}
        onClose={() => setSavesOpen(false)}
        onLoad={(sv) => {
          game.loadGame(sv);
          setSavesOpen(false);
        }}
      />
    </div>
  );
}
