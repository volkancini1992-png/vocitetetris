import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivePiece,
  Cell,
  COLS,
  KICKS,
  LINE_SCORES,
  ROWS,
  collides,
  createBoard,
  generateLevelBoard,
  dropDistance,
  lockDelayForLevel,
  newBag,
  PieceKey,
  rotate,
  spawnPiece,
  speedForLevel,
} from "../lib/tetromino";
import { audio } from "../lib/audio";
import { persistSave, snapshotSave, type SavePayload } from "../lib/save";
import {
  BONUS_PER_LEVEL,
  BONUS_UNLOCK_SCORE,
  LastPlaced,
  Relocating,
  cellsEqual,
  lastPlacedIntact,
  pieceCells,
  placementValid,
  remapAfterClear,
  worldCells,
  writeCells,
} from "../lib/bonus";

export type Status = "ready" | "playing" | "paused" | "over";

export interface GameState {
  runId: number;
  board: Cell[][];
  current: ActivePiece | null;
  queue: PieceKey[];
  bonusLeft: number;
  lastPlaced: LastPlaced | null;
  relocating: Relocating | null;
  score: number;
  lines: number;
  level: number;
  combo: number;
  pieces: number;
  status: Status;
  clearing: number[];
  toast: { text: string; sub?: string; id: number } | null;
  best: number;
  bomb: { x: number; y: number } | null;
  bombPick: boolean;
  boom: { x: number; y: number }[];
  bombNeed: number;
}

const BEST_KEY = "tetris-tr-best";
let runCounter = 0;

const initialState = (): GameState => ({
  runId: ++runCounter,
  board: createBoard(),
  current: null,
  queue: [...newBag(), ...newBag()],
  bonusLeft: BONUS_PER_LEVEL,
  lastPlaced: null,
  relocating: null,
  score: 0,
  lines: 0,
  level: 1,
  combo: 0,
  pieces: 0,
  status: "ready",
  clearing: [],
  toast: null,
  best: Number(localStorage.getItem(BEST_KEY) ?? 0),
  bomb: null,
  bombPick: false,
  boom: [],
  bombNeed: 9000,
});

const idleTiming = () => ({
  last: 0,
  drop: 0,
  lock: 0,
  lockResets: 0,
  dasDir: 0,
  dasTimer: 0,
  dasCharged: false,
  freeze: 0,
  grounded: false,
});

export function useTetris() {
  const stateRef = useRef<GameState | null>(null);
  if (stateRef.current === null) stateRef.current = initialState();
  const state = stateRef as { current: GameState };
  const [, setVersion] = useState(0);
  const render = useCallback(() => setVersion((v) => v + 1), []);

  const keys = useRef({ left: false, right: false, down: false });
  const timing = useRef(idleTiming());
  const held = useRef(false);
  const bombAcc = useRef(0);

  const refillQueue = () => {
    const s = state.current;
    while (s.queue.length < 7) s.queue.push(...newBag());
  };

  const showToast = (text: string, sub?: string) => {
    state.current.toast = { text, sub, id: Date.now() };
    window.setTimeout(() => {
      if (state.current.toast && Date.now() - state.current.toast.id >= 1000) {
        state.current.toast = null;
        render();
      }
    }, 1150);
  };

  const grantScore = (n: number) => {
    const s = state.current;
    s.score += n;
    if (!s.bomb && !s.bombPick) {
      s.bombNeed = Math.max(0, s.bombNeed - n);
      if (s.bombNeed === 0) {
        s.bomb = { x: Math.floor(Math.random() * COLS), y: 0 };
        s.bombNeed = 9000;
        showToast("💣 BONUS", "İkona dokun!");
      }
    }
  };

  const endGame = () => {
    const s = state.current;
    if (s.relocating) {
      writeCells(s.board, s.relocating.from, s.relocating.key);
      s.relocating = null;
    }
    s.status = "over";
    if (s.score > s.best) {
      s.best = s.score;
      localStorage.setItem(BEST_KEY, String(s.score));
    }
    audio.stopMusic();
    audio.gameOver();
  };

  const nextPiece = () => {
    const s = state.current;
    refillQueue();
    const key = s.queue.shift() as PieceKey;
    const piece = spawnPiece(key);
    s.current = piece;
    timing.current.lock = 0;
    timing.current.lockResets = 0;
    timing.current.drop = 0;
    if (collides(s.board, piece)) {
      s.current = piece;
      endGame();
    }
  };

  const beginLevel = (level: number) => {
    const s = state.current;
    s.level = level;
    s.board = generateLevelBoard(level);
    s.lastPlaced = null;
    s.relocating = null;
    s.bonusLeft = BONUS_PER_LEVEL;
    s.combo = 0;
    s.pieces = 0;
    s.current = null;
    s.clearing = [];
    s.bomb = null;
    s.bombPick = false;
    s.boom = [];
    timing.current = idleTiming();
    keys.current = { left: false, right: false, down: false };
    nextPiece();
    const changed = audio.setLevel(s.level);
    audio.levelUp();
    showToast(`SEVİYE ${s.level}`, changed ? `♫ ${changed.name}` : level >= 5 ? "Çelik engeller!" : "Yeni boş tahta");
  };

  const undoLast = () => {
    const s = state.current;
    if (s.status !== "playing" || s.clearing.length || s.relocating) return;
    if (s.bonusLeft <= 0) {
      showToast("HAK BİTTİ", "Bu seviyede 3 geri alma");
      audio.ui();
      render();
      return;
    }
    const lp = s.lastPlaced;
    if (!lp || !lastPlacedIntact(s.board, lp)) {
      showToast("GERİ ALINAMAZ", "Geri alınacak hamle yok");
      audio.ui();
      render();
      return;
    }
    writeCells(s.board, lp.cells, null);
    if (s.current) s.queue.unshift(s.current.key);
    s.current = spawnPiece(lp.key);
    s.lastPlaced = null;
    s.bonusLeft -= 1;
    timing.current.lock = 0;
    timing.current.drop = 0;
    audio.hold();
    try {
      const got = JSON.parse(localStorage.getItem("voci-ach") || "{}");
      got.undo = true;
      localStorage.setItem("voci-ach", JSON.stringify(got));
    } catch {
      /* yoksay */
    }
    showToast("HAMLE GERİ ALINDI", `Kalan hak: ${s.bonusLeft}/3`);
    render();
  };

  const fullRows = (board: Cell[][]): number[] => {
    const full: number[] = [];
    for (let y = 0; y < ROWS; y++) {
      if (board[y].every((c) => c !== null)) full.push(y);
    }
    return full;
  };

  const finishClear = (rows: number[], spawnNext: boolean) => {
    const s = state.current;
    const kept = s.board.filter((_, y) => !rows.includes(y));
    while (kept.length < ROWS) kept.unshift(Array<Cell>(COLS).fill(null));
    s.board = kept;
    s.clearing = [];

    if (s.lastPlaced) {
      const remapped = remapAfterClear(s.lastPlaced.cells, rows);
      s.lastPlaced = remapped ? { key: s.lastPlaced.key, cells: remapped } : null;
    }

    const n = rows.length;
    const gained = LINE_SCORES[n] * s.level + (s.combo > 0 ? s.combo * 50 * s.level : 0);
    grantScore(gained);
    s.lines += n;
    s.combo += 1;

    const newLevel = Math.floor(s.lines / 10) + 1;
    if (newLevel > s.level) {
      beginLevel(newLevel);
      timing.current.freeze = 0;
      render();
      return;
    }
    if (n === 4) showToast("TETRIS!", `+${gained} puan`);
    else if (s.combo > 2) showToast(`${s.combo - 1}x KOMBO`, `+${gained} puan`);

    if (spawnNext) nextPiece();
    timing.current.freeze = 0;
    render();
  };

  const startClear = (full: number[], spawnNext: boolean) => {
    const s = state.current;
    s.clearing = full;
    audio.clear(full.length);
    timing.current.freeze = 330;
    const id = s.runId;
    render();
    window.setTimeout(() => {
      if (state.current.runId !== id || state.current.status === "over") return;
      finishClear(full, spawnNext);
    }, 330);
  };

  const lockPiece = () => {
    const s = state.current;
    const p = s.current;
    if (!p) return;

    const cells = pieceCells(p);
    for (const c of cells) {
      if (c.y < 0) {
        endGame();
        render();
        return;
      }
      s.board[c.y][c.x] = p.key;
    }
    s.lastPlaced = { key: p.key, cells };
    s.current = null;
    s.pieces += 1;
    audio.lock();

    const full = fullRows(s.board);
    if (full.length > 0) startClear(full, true);
    else {
      s.combo = 0;
      nextPiece();
      render();
    }
  };

  const tryMove = (dx: number, dy: number): boolean => {
    const s = state.current;
    if (!s.current) return false;
    const cand = { ...s.current, x: s.current.x + dx, y: s.current.y + dy };
    if (collides(s.board, cand)) return false;
    s.current = cand;
    if (dx !== 0 && timing.current.grounded && timing.current.lockResets < 15) {
      timing.current.lock = 0;
      timing.current.lockResets++;
    }
    return true;
  };

  const tryRotate = (dir: 1 | -1) => {
    const s = state.current;
    if (!s.current || s.status !== "playing" || s.relocating) return;
    const rotated = rotate(s.current.matrix, dir);
    for (const kick of KICKS) {
      const cand = { ...s.current, matrix: rotated, x: s.current.x + kick };
      if (!collides(s.board, cand)) {
        s.current = cand;
        audio.rotate();
        if (timing.current.grounded && timing.current.lockResets < 15) {
          timing.current.lock = 0;
          timing.current.lockResets++;
        }
        render();
        return;
      }
      const candUp = { ...s.current, matrix: rotated, x: s.current.x + kick, y: s.current.y - 1 };
      if (!collides(s.board, candUp)) {
        s.current = candUp;
        audio.rotate();
        render();
        return;
      }
    }
  };

  const hardDrop = () => {
    const s = state.current;
    if (!s.current || s.status !== "playing" || s.clearing.length || s.relocating) return;
    const d = dropDistance(s.board, s.current);
    s.current = { ...s.current, y: s.current.y + d };
    grantScore(d * 2);
    audio.hardDrop();
    lockPiece();
    render();
  };

  const haltFalling = () => {
    timing.current.drop = 0;
    timing.current.lock = 0;
    timing.current.last = 0;
    timing.current.dasDir = 0;
    timing.current.dasTimer = 0;
    timing.current.dasCharged = false;
    keys.current = { left: false, right: false, down: false };
  };

  const resumeFalling = () => {
    timing.current.last = 0;
    timing.current.drop = 0;
    timing.current.lock = 0;
    keys.current = { left: false, right: false, down: false };
  };

  const cancelRelocate = () => {
    const s = state.current;
    if (!s.relocating) return;
    writeCells(s.board, s.relocating.from, s.relocating.key);
    s.relocating = null;
    resumeFalling();
    render();
  };

  const beginRelocate = (x: number, y: number) => {
    const s = state.current;
    if (s.status !== "playing" || s.clearing.length) return;

    if (s.relocating) {
      s.relocating = { ...s.relocating, hover: { x, y }, justPicked: false };
      endRelocate();
      return;
    }

    const lp = s.lastPlaced;
    if (!lp || !lastPlacedIntact(s.board, lp) || !lp.cells.some((c) => c.x === x && c.y === y)) {
      return;
    }

    if (s.score < BONUS_UNLOCK_SCORE) {
      showToast("KİLİTLİ", `${BONUS_UNLOCK_SCORE} puana ulaş`);
      audio.ui();
      render();
      return;
    }
    if (s.bonusLeft <= 0) {
      showToast("HAK BİTTİ", "Sonraki seviyede yenilenir");
      audio.ui();
      render();
      return;
    }

    writeCells(s.board, lp.cells, null);
    haltFalling();
    s.relocating = {
      key: lp.key,
      rel: lp.cells.map((c) => ({ x: c.x - x, y: c.y - y })),
      from: lp.cells.map((c) => ({ ...c })),
      hover: { x, y },
      justPicked: false,
    };
    audio.hold();
    render();
  };

  const moveRelocate = (x: number, y: number) => {
    const s = state.current;
    if (!s.relocating) return;
    const cx = Math.max(0, Math.min(COLS - 1, x));
    const cy = Math.max(0, Math.min(ROWS - 1, y));
    if (s.relocating.hover && s.relocating.hover.x === cx && s.relocating.hover.y === cy) return;
    s.relocating = { ...s.relocating, hover: { x: cx, y: cy }, justPicked: false };
    render();
  };

  const hoverOut = () => {
    /* bonus sırasında bloğu parmağın son hücresinde tut */
  };

  const endRelocate = () => {
    const s = state.current;
    const drag = s.relocating;
    if (!drag) return;

    if (s.status !== "playing") {
      cancelRelocate();
      return;
    }

    const dest = drag.hover ? worldCells(drag.rel, drag.hover) : null;
    const valid = dest ? placementValid(s.board, dest, s.current) : false;

    if (!valid || !dest) {
      writeCells(s.board, drag.from, drag.key);
      s.relocating = null;
      resumeFalling();
      audio.ui();
      showToast("İPTAL", "Blok eski yerinde");
      render();
      return;
    }

    if (cellsEqual(dest, drag.from)) {
      writeCells(s.board, drag.from, drag.key);
      s.relocating = null;
      resumeFalling();
      render();
      return;
    }

    writeCells(s.board, dest, drag.key);
    s.lastPlaced = { key: drag.key, cells: dest };
    s.relocating = null;
    s.bonusLeft -= 1;
    resumeFalling();
    audio.lock();
    showToast("BLOK TAŞINDI", `Kalan hak: ${s.bonusLeft}/${BONUS_PER_LEVEL}`);

    const full = fullRows(s.board);
    if (full.length > 0) startClear(full, false);
    else render();
  };

  useEffect(() => {
    let raf = 0;
    const frame = (t: number) => {
      const tm = timing.current;
      const dt = tm.last ? Math.min(t - tm.last, 120) : 16;
      tm.last = t;
      const s = state.current;

      if (s.status === "playing") {
        if (s.bomb && !s.bombPick && !s.relocating) {
          bombAcc.current += dt;
          if (bombAcc.current >= 420) {
            bombAcc.current = 0;
            const ny = s.bomb.y + 1;
            if (ny >= ROWS || s.board[ny][s.bomb.x]) s.bomb = null;
            else s.bomb.y = ny;
            render();
          }
        }
        if (tm.freeze > 0) {
          tm.freeze -= dt;
        } else if (s.relocating || s.bombPick) {
          /* yerçekimi durur */
        } else if (s.current) {
          let dirty = false;

          const dir = keys.current.left
            ? keys.current.right
              ? 0
              : -1
            : keys.current.right
              ? 1
              : 0;
          if (dir !== tm.dasDir) {
            tm.dasDir = dir;
            tm.dasTimer = 0;
            tm.dasCharged = false;
            if (dir !== 0 && tryMove(dir, 0)) {
              audio.move();
              dirty = true;
            }
          } else if (dir !== 0) {
            tm.dasTimer += dt;
            const need = tm.dasCharged ? 42 : 155;
            if (tm.dasTimer >= need) {
              tm.dasTimer = 0;
              tm.dasCharged = true;
              if (tryMove(dir, 0)) {
                audio.move();
                dirty = true;
              }
            }
          }

          const base = speedForLevel(s.level);
          const soft = keys.current.down;
          const interval = soft ? Math.max(24, Math.min(60, base / 6)) : base;
          tm.drop += dt;
          while (tm.drop >= interval) {
            tm.drop -= interval;
            if (tryMove(0, 1)) {
              if (soft) grantScore(1);
              tm.lock = 0;
              tm.lockResets = 0;
              dirty = true;
            } else {
              break;
            }
          }

          const grounded = collides(s.board, { ...s.current, y: s.current.y + 1 });
          tm.grounded = grounded;
          if (grounded) {
            if (held.current || s.bombPick) {
              tm.lock = 0;
            } else {
              tm.lock += dt;
              const delay = soft ? 90 : lockDelayForLevel(s.level);
              if (tm.lock >= delay) {
                tm.lock = 0;
                lockPiece();
                dirty = true;
              }
            }
          } else {
            tm.lock = 0;
          }

          if (dirty) render();
        }
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const start = useCallback(() => {
    if (state.current.relocating) {
      writeCells(state.current.board, state.current.relocating.from, state.current.relocating.key);
    }
    const best = state.current.best;
    state.current = { ...initialState(), best, status: "playing" };
    timing.current = idleTiming();
    keys.current = { left: false, right: false, down: false };
    nextPiece();
    audio.unlock();
    audio.setLevel(1);
    audio.startMusic(true);
    render();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const togglePause = useCallback(() => {
    const s = state.current;
    if (s.status === "playing") {
      if (s.relocating) cancelRelocate();
      s.status = "paused";
      audio.stopMusic();
    } else if (s.status === "paused") {
      s.status = "playing";
      timing.current.last = 0;
      keys.current = { left: false, right: false, down: false };
      if (audio.musicOn) audio.startMusic(false);
    }
    render();
  }, [render]);

  const saveGame = useCallback(() => {
    const s = state.current;
    if (s.status !== "playing" && s.status !== "paused") {
      showToast("KAYIT YOK", "Önce oyunu başlat");
      render();
      return;
    }
    if (s.relocating) cancelRelocate();
    persistSave(snapshotSave(s));
    showToast("KAYDEDİLDİ", "Kayıtlı Oyunlar sekmesinde");
    audio.ui();
    render();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadGame = useCallback((parsed: SavePayload) => {
    const best = state.current.best;
    state.current = {
      runId: ++runCounter,
      board: parsed.board,
      current: parsed.current,
      queue: parsed.queue,
      bonusLeft: parsed.bonusLeft,
      lastPlaced: parsed.lastPlaced,
      relocating: null,
      score: parsed.score,
      lines: parsed.lines,
      level: parsed.level,
      combo: parsed.combo,
      pieces: parsed.pieces,
      status: "paused",
      clearing: [],
      bomb: null,
      bombPick: false,
      boom: [],
      bombNeed: 9000,
      toast: {
        text: "KAYIT YÜKLENDİ",
        sub: `Seviye ${parsed.level} · ${parsed.score} puan`,
        id: Date.now(),
      },
      best: Math.max(best, parsed.score),
    };
    while (state.current.queue.length < 7) state.current.queue.push(...newBag());
    timing.current = idleTiming();
    keys.current = { left: false, right: false, down: false };
    audio.setLevel(parsed.level);
    audio.stopMusic();
    audio.ui();
    render();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;

      const s = state.current;
      const code = e.code;
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;

      const isPause = code === "KeyP" || key === "p";
      const isRestart = code === "KeyR" || key === "r";
      const isHard = code === "Space" || key === " " || key === "Spacebar";
      const isRotate = code === "ArrowUp" || key === "ArrowUp";
      const isRotateCCW = code === "KeyZ" || key === "z";

      const modified = e.ctrlKey || e.metaKey || e.altKey;
      if (
        ["ArrowLeft", "ArrowRight", "ArrowDown", "ArrowUp", "Space", "Enter"].includes(code) ||
        ((isPause || isRestart) && !modified)
      ) {
        e.preventDefault();
      }

      if ((e.ctrlKey || e.metaKey) && (code === "KeyS" || key === "s")) {
        e.preventDefault();
        saveGame();
        return;
      }
      if (modified) return;

      if (isRestart) {
        start();
        return;
      }
      if (isPause) {
        if (s.status === "playing" || s.status === "paused") togglePause();
        return;
      }
      if (s.status === "ready" || s.status === "over") {
        if (code === "Enter" || isHard) start();
        return;
      }
      if (s.status === "paused") return;
      if (s.status !== "playing") return;

      if (s.relocating) {
        if (code === "Escape" || key === "escape") cancelRelocate();
        return;
      }

      switch (code) {
        case "ArrowLeft":
          keys.current.left = true;
          break;
        case "ArrowRight":
          keys.current.right = true;
          break;
        case "ArrowDown":
          keys.current.down = true;
          break;
        default:
          break;
      }
      if (isRotate && !e.repeat) tryRotate(1);
      if (isRotateCCW && !e.repeat) tryRotate(-1);
      if (isHard && !e.repeat) hardDrop();
    };

    const up = (e: KeyboardEvent) => {
      if (e.code === "ArrowLeft" || e.key === "ArrowLeft") keys.current.left = false;
      if (e.code === "ArrowRight" || e.key === "ArrowRight") keys.current.right = false;
      if (e.code === "ArrowDown" || e.key === "ArrowDown") keys.current.down = false;
    };

    const blur = () => {
      keys.current = { left: false, right: false, down: false };
    };

    window.addEventListener("keydown", down, true);
    window.addEventListener("keyup", up, true);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down, true);
      window.removeEventListener("keyup", up, true);
      window.removeEventListener("blur", blur);
    };
  }, [start, togglePause, saveGame]);

  return {
    state: state.current,
    start,
    togglePause,
    hardDrop,
    saveGame,
    loadGame,
    undoLast,
    beginRelocate,
    moveRelocate,
    endRelocate,
    hoverOut,
    cancelRelocate,
    rotateCW: () => tryRotate(1),
    move: (dir: -1 | 1) => {
      if (state.current.status === "playing" && !state.current.relocating && tryMove(dir, 0)) {
        audio.move();
        render();
      }
    },
    softDrop: (on: boolean) => {
      keys.current.down = on;
    },
    setHeld: (on: boolean) => {
      held.current = on;
      if (!on) timing.current.lock = 0;
    },
    tapBomb: (x: number, y: number) => {
      const s = state.current;
      if (s.status !== "playing" || !s.bomb) return false;
      if (Math.abs(s.bomb.x - x) > 1 || Math.abs(s.bomb.y - y) > 1) return false;
      s.bomb = null;
      const cells: { x: number; y: number }[] = [];
      for (let yy = 0; yy < ROWS; yy++) {
        for (let xx = 0; xx < COLS; xx++) {
          if (s.board[yy][xx] && s.board[yy][xx] !== "G") cells.push({ x: xx, y: yy });
        }
      }
      if (!cells.length) {
        showToast("PATLATILACAK YOK", "");
        render();
        return true;
      }
      const n = Math.max(1, Math.round(cells.length * 0.4));
      for (let i = cells.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [cells[i], cells[j]] = [cells[j], cells[i]];
      }
      const boom = cells.slice(0, n);
      s.boom = boom;
      audio.boom();
      boom.forEach((c) => {
        s.board[c.y][c.x] = null;
      });
      for (let xx = 0; xx < COLS; xx++) {
        const stack: (typeof s.board)[0][0][] = [];
        for (let yy = ROWS - 1; yy >= 0; yy--) {
          if (s.board[yy][xx]) stack.push(s.board[yy][xx]);
          s.board[yy][xx] = null;
        }
        stack.forEach((cell, i) => {
          s.board[ROWS - 1 - i][xx] = cell;
        });
      }
      s.lastPlaced = null;
      s.bombPick = false;
      showToast("PATLAMA!", "Tepsinin %40'ı yok oldu");
      render();
      window.setTimeout(() => {
        state.current.boom = [];
        const full = fullRows(state.current.board);
        if (full.length) startClear(full, false);
        else render();
      }, 420);
      return true;
    },
    tapRow: (y: number) => {
      const s = state.current;
      if (!s.bombPick || s.status !== "playing") return;
      if (y < 0 || y >= ROWS) return;
      const filled = s.board[y]
        .map((c, x) => (c && c !== "G" ? x : -1))
        .filter((x) => x >= 0);
      if (!filled.length) {
        showToast("BOŞ SATIR", "Dolu bir satıra dokun");
        render();
        return;
      }
      const n = Math.max(1, Math.round(filled.length * 0.4));
      const pick = [...filled];
      for (let i = pick.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pick[i], pick[j]] = [pick[j], pick[i]];
      }
      const boom = pick.slice(0, n).map((x) => ({ x, y }));
      s.boom = boom;
      audio.boom();
      boom.forEach((c) => {
        s.board[c.y][c.x] = null;
      });
      s.bombPick = false;
      showToast("PATLAMA!", `${n} blok yok oldu`);
      render();
      window.setTimeout(() => {
        if (state.current.boom === boom) {
          state.current.boom = [];
          const full = fullRows(state.current.board);
          if (full.length) startClear(full, false);
          else render();
        }
      }, 420);
    },
    quit: () => {
      const best = state.current.best;
      state.current = { ...initialState(), best, status: "ready" };
      timing.current = idleTiming();
      held.current = false;
      audio.stopMusic();
      render();
    },
    render,
  };
}
