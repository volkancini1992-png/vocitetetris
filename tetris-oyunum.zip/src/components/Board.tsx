import { useEffect, useRef } from "react";
import {
  ActivePiece,
  Cell,
  COLORS,
  COLS,
  PIECES,
  PieceKey,
  ROWS,
  dropDistance,
  trimMatrix,
} from "../lib/tetromino";
import {
  LastPlaced,
  Relocating,
  isActiveCell,
  isLastCell,
  placementValid,
  posKey,
  worldCells,
} from "../lib/bonus";

interface Slot {
  cell: Cell;
  ghost: boolean;
  active: boolean;
  last: boolean;
  drag: boolean;
  dragOk: boolean;
}

export function Block({
  type,
  size,
  ghost = false,
  active = false,
  clearing = false,
  last = false,
  drag = false,
  dragOk = false,
}: {
  type: Exclude<Cell, null>;
  size?: number;
  ghost?: boolean;
  active?: boolean;
  clearing?: boolean;
  last?: boolean;
  drag?: boolean;
  dragOk?: boolean;
}) {
  const c = COLORS[type];
  if (ghost || drag) {
    const ok = !drag || dragOk;
    return (
      <div
        className="h-full w-full rounded-[4px]"
        style={{
          border: `2px ${drag ? "solid" : "dashed"} ${ok ? c.glow : "#f43f5e"}aa`,
          background: ok ? `${c.glow}22` : "#f43f5e33",
          boxShadow: drag ? `0 0 12px ${ok ? c.glow : "#f43f5e"}99` : undefined,
          width: size,
          height: size,
        }}
      />
    );
  }
  return (
    <div
      className="h-full w-full rounded-[5px]"
      style={{
        width: size,
        height: size,
        background: `linear-gradient(150deg, ${c.from} 0%, ${c.to} 78%)`,
        boxShadow: clearing
          ? `0 0 22px 6px #fff, inset 0 0 0 2px #fff`
          : last
            ? `inset 0 2px 0 0 ${c.edge}cc, 0 0 14px 2px #fbbf24cc, inset 0 0 0 2px #fde68a`
            : `inset 0 2px 0 0 ${c.edge}cc, inset 0 -3px 6px 0 rgba(0,0,0,.45), 0 0 ${
                active ? 14 : 7
              }px ${c.glow}${active ? "aa" : "55"}`,
        filter: clearing ? "brightness(2.2)" : undefined,
        outline: last ? "2px dashed #fbbf24" : undefined,
        outlineOffset: last ? "-2px" : undefined,
        cursor: last ? "grab" : undefined,
        transition: "filter 120ms linear",
      }}
    />
  );
}

export function MiniPiece({
  pieceKey,
  cell = 20,
  dimmed = false,
}: {
  pieceKey: PieceKey | null;
  cell?: number;
  dimmed?: boolean;
}) {
  if (!pieceKey) {
    return (
      <div className="flex items-center justify-center text-[8px] text-white/30" style={{ height: cell * 2 }}>
        —
      </div>
    );
  }
  const shape = trimMatrix(PIECES[pieceKey].matrix);
  return (
    <div className="flex items-center justify-center py-1" style={{ opacity: dimmed ? 0.35 : 1 }}>
      <div className="grid gap-[3px]" style={{ gridTemplateColumns: `repeat(${shape[0].length}, ${cell}px)` }}>
        {shape.flatMap((row, y) =>
          row.map((v, x) => (
            <div key={`${x}-${y}`} style={{ width: cell, height: cell }}>
              {v ? <Block type={pieceKey} /> : null}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export function Board({
  board,
  current,
  clearing,
  dim,
  lastPlaced,
  relocating,
  bonusReady,
  onPick,
  onDrag,
  onDrop,
  onOut,
  onSwipe,
  onSoft,
  onRotate,
  onHard,
  onHold,
  bomb,
  bombPick,
  boom,
  onBomb,
  onRow,
}: {
  board: Cell[][];
  current: ActivePiece | null;
  clearing: number[];
  dim: boolean;
  lastPlaced: LastPlaced | null;
  relocating: Relocating | null;
  bonusReady: boolean;
  onPick: (x: number, y: number) => void;
  onDrag: (x: number, y: number) => void;
  onDrop: () => void;
  onOut: () => void;
  onSwipe: (dir: -1 | 1) => void;
  // onOut: bonus sürüklerken kenarda son hücrede kalır

  onSoft: (on: boolean) => void;
  onRotate: () => void;
  onHard: () => void;
  onHold: (on: boolean) => void;
  bomb: { x: number; y: number } | null;
  bombPick: boolean;
  boom: { x: number; y: number }[];
  onBomb: (x: number, y: number) => boolean;
  onRow: (y: number) => void;
}) {
  const gridRef = useRef<HTMLDivElement>(null);
  void onOut;
  void onPick;
  type GKind = "IDLE" | "TOUCHING" | "H_DRAG" | "ROTATE" | "HARD_DROP" | "FAST_DROP" | "BONUS_DRAG";
  const gest = useRef({
    kind: "IDLE" as GKind,
    done: false,
    sx: 0,
    sy: 0,
    xSteps: 0,
    cell: null as { x: number; y: number } | null,
    holdT: 0,
  });

  const buzz = () => {
    try {
      navigator.vibrate?.(15);
    } catch {
      /* yoksay */
    }
  };

  const toCellXY = (clientX: number, clientY: number, clamp = false) => {
    const el = gridRef.current;
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return null;
    let x = Math.floor(((clientX - r.left) / r.width) * COLS);
    let y = Math.floor(((clientY - r.top) / r.height) * ROWS);
    if (clamp) {
      x = Math.max(0, Math.min(COLS - 1, x));
      y = Math.max(0, Math.min(ROWS - 1, y));
      return { x, y };
    }
    if (x < 0 || x >= COLS || y < 0 || y >= ROWS) return null;
    return { x, y };
  };

  const toCell = (e: { clientX: number; clientY: number }) => toCellXY(e.clientX, e.clientY);

  const finishTouch = () => {
    const g = gest.current;
    if (g.done) return;
    g.done = true;
    window.clearTimeout(g.holdT);
    if (g.kind === "FAST_DROP") onSoft(false);
    if (g.kind === "BONUS_DRAG") onDrop();
    g.kind = "IDLE";
    onHold(false);
  };

  useEffect(() => {
    const move = (e: PointerEvent) => {
      if (gest.current.kind !== "BONUS_DRAG" && !relocating) return;
      const cell = toCellXY(e.clientX, e.clientY, true);
      if (cell) onDrag(cell.x, cell.y);
    };
    const up = () => finishTouch();
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [!!relocating]); // eslint-disable-line react-hooks/exhaustive-deps

  const dest =
    relocating && relocating.hover ? worldCells(relocating.rel, relocating.hover) : null;
  const destOk = dest ? placementValid(board, dest, current) : false;
  const destSet = new Set((dest ?? []).map(posKey));

  const grid: Slot[][] = board.map((row, y) =>
    row.map((cell, x) => ({
      cell,
      ghost: false,
      active: false,
      last: bonusReady && !relocating && isLastCell(lastPlaced, x, y),
      drag: false,
      dragOk: false,
    }))
  );

  if (current) {
    if (!relocating) {
      const gy = current.y + dropDistance(board, current);
      current.matrix.forEach((row, y) =>
        row.forEach((v, x) => {
          if (!v) return;
          const bx = current.x + x;
          const by = gy + y;
          if (by >= 0 && by < ROWS && bx >= 0 && bx < COLS && !grid[by][bx].cell) {
            grid[by][bx] = { ...grid[by][bx], cell: current.key, ghost: true };
          }
        })
      );
    }
    current.matrix.forEach((row, y) =>
      row.forEach((v, x) => {
        if (!v) return;
        const bx = current.x + x;
        const by = current.y + y;
        if (by >= 0 && by < ROWS && bx >= 0 && bx < COLS) {
          grid[by][bx] = {
            ...grid[by][bx],
            cell: current.key,
            ghost: false,
            active: !relocating,
            last: false,
          };
        }
      })
    );
  }

  if (relocating && dest) {
    dest.forEach((c) => {
      if (c.y >= 0 && c.y < ROWS && c.x >= 0 && c.x < COLS) {
        grid[c.y][c.x] = {
          ...grid[c.y][c.x],
          cell: relocating.key,
          drag: true,
          dragOk: destOk,
          ghost: false,
          active: false,
          last: false,
        };
      }
    });
  }

  return (
    <div
      className="relative h-full w-full overflow-hidden"
      style={{
        background: "linear-gradient(160deg, rgba(9,10,32,0.96) 0%, rgba(20,8,45,0.96) 100%)",
      }}
    >
      <div
        ref={gridRef}
        className="grid h-full w-full"
        style={{
          gridTemplateColumns: `repeat(${COLS}, 1fr)`,
          gridTemplateRows: `repeat(${ROWS}, 1fr)`,
          background:
            "linear-gradient(rgba(255,255,255,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.04) 1px, transparent 1px)",
          backgroundSize: "10% 5%",
          filter: dim ? "blur(3px) brightness(0.5)" : undefined,
          transition: "filter 200ms ease",
          touchAction: "none",
          userSelect: "none",
          cursor: relocating ? "grabbing" : undefined,
        }}
        onPointerDown={(e) => {
          if (dim) return;
          e.preventDefault();
          const cell = toCell(e);
          if (bombPick) {
            if (cell) onRow(cell.y);
            return;
          }
          if (cell && bomb && onBomb(cell.x, cell.y)) return;
          onHold(true);
          try {
            e.currentTarget.setPointerCapture(e.pointerId);
          } catch {
            /* yoksay */
          }
          const g = gest.current;
          window.clearTimeout(g.holdT);
          g.kind = "TOUCHING";
          g.done = false;
          g.sx = e.clientX;
          g.sy = e.clientY;
          g.xSteps = 0;
          g.cell = cell;
          if (relocating) {
            g.kind = "BONUS_DRAG";
            return;
          }
          const onActive = !!(cell && isActiveCell(current, cell.x, cell.y));
          g.holdT = window.setTimeout(() => {
            if (g.kind !== "TOUCHING") return;
            if (onActive) {
              g.kind = "FAST_DROP";
              onSoft(true);
              buzz();
            }
          }, 380);
        }}
        onPointerMove={(e) => {
          if (dim) return;
          const g = gest.current;
          if (g.kind === "BONUS_DRAG") {
            const cell = toCellXY(e.clientX, e.clientY, true);
            if (cell) onDrag(cell.x, cell.y);
            return;
          }
          if (g.kind === "FAST_DROP" || g.kind === "HARD_DROP" || g.kind === "ROTATE") return;
          if (g.kind === "IDLE") return;

          const dx = e.clientX - g.sx;
          const dy = e.clientY - g.sy;
          const adx = Math.abs(dx);
          const ady = Math.abs(dy);
          if (g.kind === "TOUCHING") {
            if (adx < 26 && ady < 22) return;
            window.clearTimeout(g.holdT);
            if (adx >= ady) {
              g.kind = "H_DRAG";
            } else if (dy < 0) {
              g.kind = "ROTATE";
              onRotate();
              buzz();
              return;
            } else {
              g.kind = "HARD_DROP";
              onHard();
              buzz();
              return;
            }
          }

          if (g.kind === "H_DRAG") {
            const cellW = Math.max(8, (gridRef.current?.getBoundingClientRect().width || 200) / COLS);
            const step = Math.round(dx / (cellW * 1.4));
            if (step !== g.xSteps) {
              const dir = step > g.xSteps ? 1 : -1;
              const n = Math.abs(step - g.xSteps);
              for (let i = 0; i < n; i++) onSwipe(dir);
              if (n > 0) buzz();
              g.xSteps = step;
            }
          }
        }}
        onPointerUp={() => finishTouch()}
        onPointerCancel={() => finishTouch()}
      >
        {grid.flatMap((row, y) =>
          row.map((slot, x) => (
            <div
              key={`${x}-${y}`}
              className="rounded-[5px]"
              style={{
                background: slot.cell ? undefined : "rgba(255,255,255,0.028)",
              }}
            >
              {boom.some((b) => b.x === x && b.y === y) ? (
                <div className="boom-cell h-full w-full" />
              ) : bomb && bomb.x === x && bomb.y === y ? (
                <div className="pointer-events-none relative z-20 flex h-full w-full items-center justify-center">
                  <span className="absolute text-[min(12vw,52px)] leading-none drop-shadow-[0_0_12px_#fb923c] scale-[2]">
                    💣
                  </span>
                </div>
              ) : slot.cell ? (
                <Block
                  type={slot.cell}
                  ghost={slot.ghost}
                  active={slot.active}
                  clearing={clearing.includes(y)}
                  last={slot.last}
                  drag={slot.drag}
                  dragOk={slot.dragOk}
                />
              ) : destSet.has(`${x},${y}`) ? null : null}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
