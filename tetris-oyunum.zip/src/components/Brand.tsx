import { MouseCursorIcon, VociLogo } from "./VociLogo";

export function DeveloperFooter() {
  return (
    <footer className="flex h-7 w-full shrink-0 items-center justify-between gap-2 overflow-hidden border-t border-white/10 bg-slate-950/90 px-2">
      <a
        href="https://voci.com.tr"
        target="_blank"
        rel="noopener noreferrer"
        className="flex min-w-0 items-center gap-1.5"
      >
        <span className="rounded bg-white p-px">
          <VociLogo className="h-5 w-auto" />
        </span>
        <span className="truncate text-[9px] font-black tracking-wider text-cyan-200">
          VOCİ TECHNOLOGIES · BY VOLKAN ÇİNİ
        </span>
      </a>
      <a
        href="https://voci.com.tr"
        target="_blank"
        rel="noopener noreferrer"
        className="flex shrink-0 items-center gap-1 text-[9px] font-bold text-cyan-200"
      >
        <MouseCursorIcon className="h-3 w-3" />
        voci.com.tr
      </a>
    </footer>
  );
}
