import { APP_ICON } from "../brand";
import type { Status } from "../hooks/useTetris";

export function GameMenu({
  open,
  status,
  music,
  sfx,
  onClose,
  onPause,
  onRestart,
  onSave,
  onSaves,
  onMusic,
  onSfx,
  onQuit,
}: {
  open: boolean;
  status: Status;
  music: boolean;
  sfx: boolean;
  onClose: () => void;
  onPause: () => void;
  onRestart: () => void;
  onSave: () => void;
  onSaves: () => void;
  onMusic: () => void;
  onSfx: () => void;
  onQuit: () => void;
}) {
  if (!open) return null;
  const playing = status === "playing" || status === "paused";
  return (
    <div className="fixed inset-0 z-[20000] flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-sm rounded-2xl bg-[#0b1220] p-4 ring-2 ring-cyan-300/40">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={APP_ICON} alt="" className="h-9 w-9 rounded-xl object-cover ring-2 ring-cyan-300/40" />
            <div className="text-sm font-black tracking-[0.2em] text-cyan-200">MENÜ</div>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg bg-white/10 px-3 py-1 text-sm font-bold">
            Kapat
          </button>
        </div>
        <div className="grid gap-2">
          <MenuBtn onClick={onPause} disabled={!playing}>
            {status === "paused" ? "▶ Devam et" : "⏸ Duraklat"}
          </MenuBtn>
          <MenuBtn onClick={onSave} disabled={!playing}>
            💾 Oyunu kaydet
          </MenuBtn>
          <MenuBtn onClick={onSaves}>📂 Kayıtlı oyunlar</MenuBtn>
          <MenuBtn onClick={onMusic}>{music ? "♫ Müzik açık" : "♪ Müzik kapalı"}</MenuBtn>
          <MenuBtn onClick={onSfx}>{sfx ? "🔊 Ses açık" : "🔇 Ses kapalı"}</MenuBtn>
          <MenuBtn onClick={onRestart}>⟳ Yeni oyun</MenuBtn>
          <MenuBtn onClick={onQuit}>⏻ Oyunu kapat</MenuBtn>
        </div>
      </div>
    </div>
  );
}

function MenuBtn({
  children,
  onClick,
  disabled,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className="rounded-xl bg-white/10 px-4 py-3 text-left text-sm font-bold text-white ring-1 ring-white/15 disabled:opacity-40"
    >
      {children}
    </button>
  );
}
