import { ReactNode } from "react";
import { MiniPiece } from "./Board";
import { PieceKey, speedForLevel } from "../lib/tetromino";
import type { Status } from "../hooks/useTetris";
import { BONUS_PER_LEVEL, BONUS_UNLOCK_SCORE } from "../lib/bonus";

export function Panel({
  title,
  children,
  className = "",
  accent = "cyan",
}: {
  title?: string;
  children: ReactNode;
  className?: string;
  accent?: "cyan" | "fuchsia" | "amber";
}) {
  const ring = {
    cyan: "ring-cyan-300/25 shadow-[0_0_30px_-14px_rgba(34,211,238,0.9)]",
    fuchsia: "ring-fuchsia-300/25 shadow-[0_0_30px_-14px_rgba(232,121,249,0.9)]",
    amber: "ring-amber-300/25 shadow-[0_0_30px_-14px_rgba(251,191,36,0.9)]",
  }[accent];
  return (
    <div className={`rounded-2xl bg-slate-950/55 p-3 ring-1 backdrop-blur-md ${ring} ${className}`}>
      {title && (
        <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.22em] text-white/45">{title}</div>
      )}
      {children}
    </div>
  );
}

export function StatCard({
  label,
  value,
  accent,
  big = false,
  compact = false,
}: {
  label: string;
  value: string | number;
  accent: string;
  big?: boolean;
  compact?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl bg-slate-950/55 ring-1 ring-white/10 backdrop-blur-md ${
        compact ? "px-2 py-1" : "px-4 py-2"
      }`}
    >
      <div className={`font-bold uppercase tracking-[0.18em] text-white/45 ${compact ? "text-[8px]" : "text-[10px]"}`}>
        {label}
      </div>
      <div
        className={`font-mono font-black tabular-nums ${
          compact ? "text-base leading-tight" : big ? "text-3xl sm:text-4xl" : "text-xl sm:text-2xl"
        }`}
        style={{ color: accent, textShadow: `0 0 18px ${accent}80` }}
      >
        {value}
      </div>
    </div>
  );
}

export function NextPanel({ queue }: { queue: PieceKey[] }) {
  return (
    <Panel title="Sıradaki" accent="fuchsia" className="w-[150px]">
      <div className="rounded-xl bg-black/35 py-1 ring-1 ring-white/5">
        <MiniPiece pieceKey={queue[0] ?? null} cell={19} />
      </div>
      <div className="mt-2 flex items-center justify-center gap-2">
        {queue.slice(1, 3).map((k, i) => (
          <div key={i} className="flex-1 rounded-lg bg-black/25 ring-1 ring-white/5">
            <MiniPiece pieceKey={k} cell={10} dimmed />
          </div>
        ))}
      </div>
    </Panel>
  );
}

export function BonusPanel({ bonusLeft, score }: { bonusLeft: number; score: number }) {
  const unlocked = score >= BONUS_UNLOCK_SCORE;
  return (
    <Panel title="Bonus hamle" accent="amber" className="w-[150px]">
      <div className="rounded-xl bg-black/35 px-2 py-3 text-center ring-1 ring-white/5">
        <div className="text-2xl">{unlocked ? "🖱️" : "🔒"}</div>
        <div className="mt-1 text-[11px] font-bold leading-snug text-amber-100">
          {unlocked ? "Son bloğu sürükle" : `${BONUS_UNLOCK_SCORE} puan gerekli`}
        </div>
      </div>
      <div className="mt-2 flex items-center justify-center gap-1.5">
        {Array.from({ length: BONUS_PER_LEVEL }, (_, i) => (
          <span
            key={i}
            className={`h-2.5 w-2.5 rounded-full ${
              unlocked && i < bonusLeft ? "bg-amber-300 shadow-[0_0_8px_#fbbf24]" : "bg-white/15"
            }`}
          />
        ))}
      </div>
      <div className="mt-1 text-center text-[10px] text-white/50">
        {!unlocked
          ? `${Math.max(0, BONUS_UNLOCK_SCORE - score)} puan kaldı`
          : bonusLeft > 0
            ? `Bu seviye: ${bonusLeft}/${BONUS_PER_LEVEL} hak`
            : "Hak bitti · sonraki seviye"}
      </div>
    </Panel>
  );
}

export function LevelProgress({ lines, level }: { lines: number; level: number }) {
  const inLevel = lines % 10;
  const pct = (inLevel / 10) * 100;
  const speed = speedForLevel(level);
  return (
    <Panel title="Seviye ilerlemesi" className="w-[150px]">
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/10">
        <div
          className="h-full rounded-full bg-gradient-to-r from-cyan-300 via-sky-400 to-fuchsia-500 transition-[width] duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="mt-2 flex justify-between text-[11px] text-white/55">
        <span>{inLevel}/10 satır</span>
        <span className="font-mono">{speed}ms</span>
      </div>
      {level >= 5 && (
        <div className="mt-2 rounded-lg bg-rose-500/15 px-2 py-1 text-[10px] leading-tight text-rose-200 ring-1 ring-rose-400/30">
          ⚠ Seviye 6+: zemin periyodik olarak yükselir!
        </div>
      )}
    </Panel>
  );
}

const KEYS: [string, string][] = [
  ["◀ ▶", "Sağa / sola hareket"],
  ["▲", "Bloğu döndür"],
  ["▼ (basılı tut)", "Hızlı düşür"],
  ["Boşluk", "Anında bırak"],
  ["P", "Duraklat / devam"],
  ["R", "Yeniden başlat"],
];

export function ControlsPanel() {
  return (
    <Panel title="Kontroller" className="w-[190px]">
      <ul className="space-y-1.5">
        {KEYS.map(([k, d]) => (
          <li key={k} className="flex items-center justify-between gap-2">
            <kbd className="rounded-md bg-white/10 px-2 py-0.5 font-mono text-[11px] font-bold text-cyan-200 ring-1 ring-white/15">
              {k}
            </kbd>
            <span className="text-right text-[11px] leading-tight text-white/55">{d}</span>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

export function AudioPanel({
  music,
  sfx,
  volume,
  trackName,
  trackMood,
  auto,
  onCycleTrack,
  onMusic,
  onSfx,
  onVolume,
}: {
  music: boolean;
  sfx: boolean;
  volume: number;
  trackName: string;
  trackMood: string;
  auto: boolean;
  onCycleTrack: () => void;
  onMusic: () => void;
  onSfx: () => void;
  onVolume: (v: number) => void;
}) {
  const btn = (on: boolean) =>
    `flex-1 rounded-lg px-2 py-1.5 text-[11px] font-bold transition ${
      on
        ? "bg-cyan-400/20 text-cyan-200 ring-1 ring-cyan-300/50"
        : "bg-white/5 text-white/35 ring-1 ring-white/10"
    }`;
  return (
    <Panel title="Ses & Müzik" className="w-[190px]">
      <button
        type="button"
        onMouseDown={(e) => e.preventDefault()}
        onClick={onCycleTrack}
        className="mb-2 w-full rounded-lg bg-gradient-to-r from-fuchsia-500/20 to-cyan-400/20 px-2 py-1.5 text-left ring-1 ring-fuchsia-300/30 transition hover:from-fuchsia-500/30 hover:to-cyan-400/30"
      >
        <div className="truncate text-[11px] font-black text-fuchsia-200">♫ {trackName}</div>
        <div className="flex items-center justify-between text-[9px] uppercase tracking-wider text-white/40">
          <span>{trackMood}</span>
          <span className={auto ? "text-emerald-300/70" : "text-amber-300/70"}>
            {auto ? "otomatik" : "manuel"}
          </span>
        </div>
      </button>
      <div className="flex gap-2">
        <button type="button" onMouseDown={(e) => e.preventDefault()} className={btn(music)} onClick={onMusic}>
          {music ? "♫ Müzik" : "♪ Kapalı"}
        </button>
        <button type="button" onMouseDown={(e) => e.preventDefault()} className={btn(sfx)} onClick={onSfx}>
          {sfx ? "🔊 Efekt" : "🔇 Efekt"}
        </button>
      </div>
      <input
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={volume}
        onChange={(e) => onVolume(Number(e.target.value))}
        className="mt-3 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/15 accent-fuchsia-400"
      />
    </Panel>
  );
}

const btnBase =
  "rounded-xl px-3 py-2.5 text-[11px] font-black uppercase tracking-widest ring-1 transition active:scale-95 disabled:cursor-not-allowed disabled:opacity-40";

export function ActionDock({
  status,
  onPause,
  onRestart,
  onSave,
  onLoad,
}: {
  status: Status;
  onPause: () => void;
  onRestart: () => void;
  onSave: () => void;
  onLoad: () => void;
}) {
  const playing = status === "playing" || status === "paused";
  return (
    <Panel title="Komutlar" className="w-[190px]">
      <div className="flex flex-col gap-2">
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()}
          onClick={onPause}
          disabled={!playing}
          className={`${btnBase} bg-cyan-400/15 text-cyan-200 ring-cyan-300/40 hover:bg-cyan-400/25`}
        >
          {status === "paused" ? "▶ Devam Et  (P)" : "⏸ Duraklat  (P)"}
        </button>
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()}
          onClick={onRestart}
          className={`${btnBase} bg-fuchsia-400/15 text-fuchsia-200 ring-fuchsia-300/40 hover:bg-fuchsia-400/25`}
        >
          ⟳ Yeniden Başlat  (R)
        </button>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={onSave}
            disabled={!playing}
            className={`${btnBase} bg-emerald-400/15 text-emerald-200 ring-emerald-300/40 hover:bg-emerald-400/25`}
          >
            💾 Kaydet
          </button>
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={onLoad}
            className={`${btnBase} bg-sky-400/15 text-sky-200 ring-sky-300/40 hover:bg-sky-400/25`}
          >
            📂 Yükle
          </button>
        </div>
      </div>
    </Panel>
  );
}

export function Overlay({
  status,
  score,
  level,
  lines,
  best,
  onStart,
  onResume,
  onLoad,
}: {
  status: Status;
  score: number;
  level: number;
  lines: number;
  best: number;
  onStart: () => void;
  onResume: () => void;
  onLoad: () => void;
}) {
  if (status === "playing") return null;

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center overflow-hidden rounded-xl bg-slate-950/80 p-2 backdrop-blur-[2px]">
      <div className="w-full max-w-[240px] overflow-hidden text-center">
        {status === "ready" && (
          <>
            <div className="mb-0.5 text-3xl sm:mb-1 sm:text-5xl">🎮</div>
            <h2 className="bg-gradient-to-r from-cyan-300 via-sky-300 to-fuchsia-400 bg-clip-text text-2xl font-black text-transparent sm:text-3xl">
              HAZIR MISIN?
            </h2>
            <p className="mt-1 text-xs text-white/60 sm:mt-2 sm:text-sm">
              Kaydır: ← → hareket · ↑ döndür · ↓ bırak. Basılı tut: hızlı düş.
            </p>
            <p className="mt-3 rounded-xl bg-amber-400/15 px-3 py-2 text-[11px] leading-snug text-amber-100 ring-1 ring-amber-300/40">
              <b>Geri al:</b> Her seviyede 3 kez, son koyduğun bloğu tahtadan çekip yeniden en üstten düşürürsün.
              Sarı <b>↩ GERİ</b> tuşuna bas. Ekranda “HAMLE GERİ ALINDI” yazar.
            </p>
          </>
        )}
        {status === "paused" && (
          <>
            <div className="mb-1 text-5xl">⏸️</div>
            <h2 className="text-3xl font-black text-amber-300">DURAKLATILDI</h2>
            <p className="mt-2 text-sm text-white/60">
              Devam için <b>P</b> · Yeniden için <b>R</b>
            </p>
          </>
        )}
        {status === "over" && (
          <>
            <div className="mb-1 text-5xl">💀</div>
            <h2 className="text-3xl font-black text-rose-400">OYUN BİTTİ</h2>
            <div className="mt-3 space-y-1 rounded-xl bg-black/40 p-3 text-sm text-white/70 ring-1 ring-white/10">
              <div className="flex justify-between">
                <span>Puan</span>
                <b className="font-mono text-cyan-300">{score}</b>
              </div>
              <div className="flex justify-between">
                <span>Seviye</span>
                <b className="font-mono text-fuchsia-300">{level}</b>
              </div>
              <div className="flex justify-between">
                <span>Satır</span>
                <b className="font-mono text-amber-300">{lines}</b>
              </div>
              <div className="flex justify-between border-t border-white/10 pt-1">
                <span>En iyi (bu cihaz)</span>
                <b className="font-mono text-emerald-300">{best}</b>
              </div>
            </div>
          </>
        )}

        <div className="mt-4 flex flex-col gap-2">
          <button
            type="button"
            onClick={status === "paused" ? onResume : onStart}
            className="w-full touch-manipulation rounded-xl bg-gradient-to-r from-cyan-400 to-fuchsia-500 px-6 py-3 text-sm font-black uppercase tracking-widest text-slate-950 shadow-[0_0_30px_-6px_rgba(34,211,238,0.9)] transition hover:scale-[1.03] active:scale-95"
          >
            {status === "ready" ? "Oyuna Başla" : status === "paused" ? "Devam Et (P)" : "Tekrar Oyna"}
          </button>
          {status === "paused" && (
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={onStart}
              className="w-full rounded-xl bg-white/10 px-6 py-2 text-xs font-bold uppercase tracking-widest text-white/70 ring-1 ring-white/15 transition hover:bg-white/15"
            >
              Yeniden Başlat (R)
            </button>
          )}
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={onLoad}
            className="w-full rounded-xl bg-sky-400/10 px-6 py-2 text-xs font-bold uppercase tracking-widest text-sky-200 ring-1 ring-sky-300/30 transition hover:bg-sky-400/20"
          >
            📂 Kayıtlı Oyunlar
          </button>
        </div>
      </div>
    </div>
  );
}
