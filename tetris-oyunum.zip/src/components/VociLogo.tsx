import { useState } from "react";
import logoPng from "../assets/logo.png?inline";

/** Resmî logo adresi (kullanıcı tarafından verilen bağlantı) */
export const LOGO_URL = "https://i.ibb.co/Y4HYNn9B/LOGO-1.png";

/**
 * VOCİ Technologies logosu.
 * 1) Öncelik : https://i.ibb.co/Y4HYNn9B/LOGO-1.png (resmî bağlantı)
 * 2) Yedek   : projeye gömülü LOGO.png
 * 3) Son çare: birebir vektörel (SVG) kopya
 */
export function VociLogo({
  className = "h-12 w-auto",
  variant = "full",
}: {
  className?: string;
  variant?: "full" | "mark";
}) {
  const [stage, setStage] = useState<0 | 1 | 2>(0);

  if (stage < 2) {
    return (
      <img
        key={stage}
        src={stage === 0 ? LOGO_URL : logoPng}
        alt="VOCİ Technologies logosu"
        onError={() => setStage((s) => (s === 0 ? 1 : 2))}
        className={`${className} select-none object-contain`}
        draggable={false}
        loading="eager"
        decoding="async"
      />
    );
  }
  return <VociLogoSvg className={className} variant={variant} />;
}

/** Logonun vektörel yeniden çizimi (yedek) */
export function VociLogoSvg({
  className = "h-12 w-auto",
  variant = "full",
}: {
  className?: string;
  variant?: "full" | "mark";
}) {
  const viewBox = variant === "mark" ? "170 0 380 300" : "0 0 640 470";

  return (
    <svg
      viewBox={viewBox}
      className={className}
      role="img"
      aria-label="VOCİ Technologies"
    >
      <defs>
        <linearGradient id="voci-blue" x1="0.05" y1="0" x2="0.75" y2="1">
          <stop offset="0%" stopColor="#8FDBF5" />
          <stop offset="22%" stopColor="#4EBCE8" />
          <stop offset="52%" stopColor="#2288CB" />
          <stop offset="80%" stopColor="#15619F" />
          <stop offset="100%" stopColor="#0E4A85" />
        </linearGradient>

        <linearGradient id="voci-chrome" x1="0.12" y1="0" x2="0.9" y2="1">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="14%" stopColor="#DFE8EE" />
          <stop offset="30%" stopColor="#A6B6C2" />
          <stop offset="44%" stopColor="#FDFEFF" />
          <stop offset="57%" stopColor="#E6EEF4" />
          <stop offset="72%" stopColor="#8A9BA8" />
          <stop offset="87%" stopColor="#D5E0E8" />
          <stop offset="100%" stopColor="#FFFFFF" />
        </linearGradient>

        <linearGradient id="voci-node" x1="0" y1="0" x2="0.6" y2="1">
          <stop offset="0%" stopColor="#7FD8F4" />
          <stop offset="100%" stopColor="#1C86C9" />
        </linearGradient>

        <linearGradient id="voci-text" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="55%" stopColor="#FFFFFF" />
          <stop offset="100%" stopColor="#DCE7EF" />
        </linearGradient>
      </defs>

      {/* ── Krom "O" halkası (okun arkasında) ── */}
      <g>
        <circle cx="398" cy="208" r="64" fill="none" stroke="url(#voci-chrome)" strokeWidth="36" />
        <circle cx="398" cy="208" r="82" fill="none" stroke="#7A8994" strokeWidth="2.5" />
        <circle cx="398" cy="208" r="46" fill="none" stroke="#7A8994" strokeWidth="2.5" />
        <path
          d="M340 150 A82 82 0 0 1 430 129"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="7"
          strokeLinecap="round"
          opacity="0.85"
        />
      </g>

      {/* ── Devre izleri (V'nin içinde) ── */}
      <g stroke="url(#voci-node)" fill="none" strokeLinecap="round">
        <path d="M300 104 L300 214" strokeWidth="9" />
        <path d="M348 112 L348 152 L320 152 L320 196" strokeWidth="8" />
      </g>
      <g>
        <circle cx="300" cy="84" r="20" fill="url(#voci-node)" />
        <circle cx="300" cy="84" r="8.5" fill="#0A3552" />
        <circle cx="348" cy="97" r="15" fill="url(#voci-node)" />
        <circle cx="348" cy="97" r="6" fill="#0A3552" />
      </g>

      {/* ── Yükselen ok biçimli "V" ── */}
      <g>
        <path
          d="M196 112 L300 290 L450 95"
          fill="none"
          stroke="#0B3E70"
          strokeWidth="68"
          strokeLinejoin="miter"
        />
        <path d="M516 14 L505 170 L367 62 Z" fill="#0B3E70" stroke="#0B3E70" strokeWidth="8" strokeLinejoin="miter" />
        <path
          d="M196 112 L300 290 L450 95"
          fill="none"
          stroke="url(#voci-blue)"
          strokeWidth="60"
          strokeLinejoin="miter"
        />
        <path d="M516 14 L505 170 L367 62 Z" fill="url(#voci-blue)" />
        {/* parlama */}
        <path d="M212 124 L300 274" fill="none" stroke="#BDEBFB" strokeWidth="7" opacity="0.55" strokeLinecap="round" />
      </g>

      {/* ── "VOCI" yazısı ── */}
      {variant === "full" && (
        <text
          x="320"
          y="445"
          textAnchor="middle"
          textLength="548"
          lengthAdjust="spacingAndGlyphs"
          fontSize="190"
          fontWeight="900"
          fontFamily="'Arial Black','Segoe UI Black',Montserrat,Impact,sans-serif"
          fill="url(#voci-text)"
          stroke="#12283E"
          strokeWidth="15"
          paintOrder="stroke"
          strokeLinejoin="round"
        >
          VOCI
        </text>
      )}
    </svg>
  );
}

/** Tıklanabilirliği vurgulayan animasyonlu fare imleci ikonu */
export function MouseCursorIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <span className={`relative inline-flex ${className}`}>
      <svg viewBox="0 0 24 24" className="h-full w-full drop-shadow-[0_0_5px_rgba(34,211,238,0.9)]">
        <path
          d="M5.4 2.6 L19.6 12.1 L12.6 13.1 L16.1 19.9 L13.2 21.3 L9.8 14.4 L4.9 18.9 Z"
          fill="currentColor"
          stroke="#0B1220"
          strokeWidth="1.2"
          strokeLinejoin="round"
        />
      </svg>
      <span className="absolute -right-1 -top-1 h-2 w-2 animate-ping rounded-full bg-cyan-300/80" />
    </span>
  );
}
