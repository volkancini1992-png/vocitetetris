import { MiniPiece } from "./Board";
import type { PieceKey } from "../lib/tetromino";

export function TopHud({
  score,
  level,
  queue,
  undoLeft,
  bombNeed,
  music,
  onUndo,
  onMenu,
  onMusic,
  onPause,
}: {
  score: number;
  level: number;
  queue: PieceKey[];
  undoLeft: number;
  bombNeed: number;
  music: boolean;
  onUndo: () => void;
  onMenu: () => void;
  onMusic: () => void;
  onPause: () => void;
}) {
  return (
    <header className="shrink-0 bg-[#020617] px-2 py-2">
      <div className="mb-1.5 grid grid-cols-3 gap-1.5">
        <Stat label="PUAN" value={score} color="#67e8f9" />
        <Stat label="SEVİYE" value={level} color="#e879f9" />
        <Stat label="💣 KALAN" value={bombNeed} color="#fb923c" />
      </div>
      <div className="flex items-stretch gap-1.5">
        <div className="flex min-w-[4.6rem] flex-col items-center justify-center rounded-xl bg-black/50 px-2 py-1 ring-2 ring-fuchsia-300/50">
          <span className="text-[9px] font-black uppercase text-white/60">Sıradaki</span>
          <MiniPiece pieceKey={queue[0] ?? null} cell={11} />
        </div>
        <button
          type="button"
          onClick={onUndo}
          className="flex min-w-[4.4rem] flex-1 flex-col items-center justify-center rounded-xl bg-amber-400 px-2 py-1 text-slate-950 ring-2 ring-amber-100"
        >
          <span className="text-xl font-black leading-none">↩</span>
          <span className="text-[11px] font-black">GERİ {undoLeft}/3</span>
        </button>
        <button
          type="button"
          onClick={onMusic}
          className="flex w-12 flex-col items-center justify-center rounded-xl bg-white/15 text-lg ring-2 ring-white/30"
        >
          {music ? "♫" : "♪"}
        </button>
        <button
          type="button"
          onClick={onPause}
          className="flex w-12 flex-col items-center justify-center rounded-xl bg-white/15 text-lg ring-2 ring-white/30"
        >
          ⏸
        </button>
        <button
          type="button"
          onClick={onMenu}
          className="flex w-12 flex-col items-center justify-center rounded-xl bg-cyan-400 text-slate-950 ring-2 ring-cyan-100"
        >
          <span className="text-xl font-black">☰</span>
        </button>
      </div>
    </header>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-xl bg-black/50 px-2 py-1.5 text-center ring-2 ring-white/25">
      <div className="text-[8px] font-black tracking-wider text-white/55">{label}</div>
      <div className="font-mono text-lg font-black leading-none tabular-nums" style={{ color }}>
        {value.toLocaleString("tr-TR")}
      </div>
    </div>
  );
}
