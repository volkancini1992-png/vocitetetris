import { SPLASH_ART } from "../brand";

export function Splash({
  onPlay,
  onLead,
  onAchieve,
  onSettings,
}: {
  onPlay: () => void;
  onLead: () => void;
  onAchieve: () => void;
  onSettings: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[30000] overflow-hidden bg-black">
      <img
        src={SPLASH_ART}
        alt="VOCİ Tetris"
        className="absolute inset-0 h-full w-full object-cover object-bottom"
        draggable={false}
      />

      {/* BAŞLA — Liderlik / Başarılar / Ayarlar sırasının hemen üstü */}
      <button
        type="button"
        aria-label="Başla"
        onClick={onPlay}
        className="absolute z-20"
        style={{ left: "10%", width: "80%", bottom: "14.2%", height: "10.5%" }}
      />

      <div
        className="absolute z-20 grid grid-cols-3"
        style={{ left: "7%", right: "7%", bottom: "3.8%", height: "10.2%", columnGap: "2.4%" }}
      >
        <button type="button" aria-label="Liderlik" className="h-full w-full" onClick={onLead} />
        <button type="button" aria-label="Başarılar" className="h-full w-full" onClick={onAchieve} />
        <button type="button" aria-label="Ayarlar" className="h-full w-full" onClick={onSettings} />
      </div>
    </div>
  );
}
