import { useState } from "react";
import { deleteSave, listSaves, type StoredSave } from "../lib/save";

export function SavesPanel({
  open,
  onClose,
  onLoad,
}: {
  open: boolean;
  onClose: () => void;
  onLoad: (save: StoredSave) => void;
}) {
  const [tick, setTick] = useState(0);
  if (!open) return null;
  const saves = listSaves();
  void tick;

  return (
    <div className="fixed inset-0 z-[20000] flex items-end justify-center bg-black/70 p-3 sm:items-center">
      <div className="flex max-h-[80dvh] w-full max-w-md flex-col overflow-hidden rounded-2xl bg-[#0b1220] ring-1 ring-cyan-300/30">
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
          <div>
            <div className="text-sm font-black tracking-wider text-cyan-200">KAYITLI OYUNLAR</div>
            <div className="text-[10px] text-white/40">Telefon kapansa da burada durur</div>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg bg-white/10 px-3 py-1 text-sm">
            Kapat
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-3">
          {saves.length === 0 && (
            <p className="py-8 text-center text-sm text-white/50">Henüz kayıt yok. Oyundayken 💾 kaydet.</p>
          )}
          <ul className="space-y-2">
            {saves.map((sv) => (
              <li key={sv.id} className="flex items-center gap-2 rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
                <div className="min-w-0 flex-1">
                  <div className="font-mono text-sm font-black text-cyan-100">
                    {sv.score} puan · Lv {sv.level}
                  </div>
                  <div className="text-[11px] text-white/45">
                    {sv.lines} satır · {new Date(sv.savedAt).toLocaleString("tr-TR")}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onLoad(sv)}
                  className="rounded-lg bg-cyan-500/20 px-3 py-1.5 text-xs font-bold text-cyan-100 ring-1 ring-cyan-300/40"
                >
                  Yükle
                </button>
                <button
                  type="button"
                  onClick={() => {
                    deleteSave(sv.id);
                    setTick((n) => n + 1);
                  }}
                  className="rounded-lg bg-rose-500/15 px-2 py-1.5 text-xs text-rose-200"
                >
                  Sil
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
