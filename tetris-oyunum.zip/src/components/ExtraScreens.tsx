import { APP_ICON } from "../brand";
import { listSaves } from "../lib/save";

export function LeadScreen({ onClose }: { onClose: () => void }) {
  const saves = listSaves()
    .slice()
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
  const best = Number(localStorage.getItem("tetris-tr-best") ?? 0);
  return (
    <Sheet title="LİDERLİK" onClose={onClose}>
      <p className="mb-4 text-center text-sm text-cyan-100/80">
        Cihaz rekoru{" "}
        <b className="font-mono text-lg text-amber-300">{best.toLocaleString("tr-TR")}</b>
      </p>
      {saves.length === 0 && <p className="text-center text-white/45">Henüz kayıtlı skor yok.</p>}
      <ol className="space-y-2">
        {saves.map((sv, i) => (
          <li
            key={sv.id}
            className="flex items-center justify-between rounded-2xl bg-gradient-to-r from-white/10 to-white/5 px-4 py-3 ring-1 ring-white/10"
          >
            <span className="flex items-center gap-3">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-cyan-400/20 font-black text-cyan-200">
                {i + 1}
              </span>
              <span className="text-sm text-white/70">Lv {sv.level}</span>
            </span>
            <b className="font-mono text-amber-200">{sv.score.toLocaleString("tr-TR")}</b>
          </li>
        ))}
      </ol>
    </Sheet>
  );
}

const ACH = [
  { id: "play", t: "İlk oyun", d: "Bir oyun başlat" },
  { id: "tetris", t: "Tetris!", d: "4 satır birden sil" },
  { id: "lv5", t: "Çelik", d: "5. seviyeye ulaş" },
  { id: "lv10", t: "Usta", d: "10. seviyeye ulaş" },
  { id: "undo", t: "Zaman bükücü", d: "Geri al kullan" },
  { id: "bomb", t: "Bombacı", d: "Patlama bonusu kullan" },
  { id: "10k", t: "10.000", d: "10.000 puana ulaş" },
];

export function AchieveScreen({ onClose }: { onClose: () => void }) {
  const got = JSON.parse(localStorage.getItem("voci-ach") || "{}") as Record<string, boolean>;
  return (
    <Sheet title="BAŞARILAR" onClose={onClose}>
      <ul className="space-y-2">
        {ACH.map((a) => (
          <li
            key={a.id}
            className={`rounded-2xl px-4 py-3 ring-1 ${
              got[a.id]
                ? "bg-gradient-to-r from-emerald-500/20 to-cyan-500/10 ring-emerald-300/40"
                : "bg-white/5 ring-white/10"
            }`}
          >
            <div className="font-bold">{got[a.id] ? "✓ " : "○ "}{a.t}</div>
            <div className="text-xs text-white/50">{a.d}</div>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}

export function SettingsScreen({
  music,
  sfx,
  onMusic,
  onSfx,
  onClose,
}: {
  music: boolean;
  sfx: boolean;
  onMusic: () => void;
  onSfx: () => void;
  onClose: () => void;
}) {
  return (
    <Sheet title="AYARLAR" onClose={onClose}>
      <button
        type="button"
        onClick={onMusic}
        className="mb-2 w-full rounded-2xl bg-gradient-to-r from-cyan-500/20 to-white/5 px-4 py-3.5 text-left font-bold ring-1 ring-white/10"
      >
        {music ? "♫  Müzik açık" : "♪  Müzik kapalı"}
      </button>
      <button
        type="button"
        onClick={onSfx}
        className="w-full rounded-2xl bg-gradient-to-r from-fuchsia-500/20 to-white/5 px-4 py-3.5 text-left font-bold ring-1 ring-white/10"
      >
        {sfx ? "🔊  Ses açık" : "🔇  Ses kapalı"}
      </button>
    </Sheet>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-[35000] flex items-end justify-center bg-black/70 p-3 backdrop-blur-md sm:items-center">
      <div className="max-h-[82dvh] w-full max-w-md overflow-y-auto rounded-3xl bg-gradient-to-b from-[#121a2e] to-[#070b14] p-5 shadow-[0_20px_60px_rgba(0,0,0,.55)] ring-1 ring-cyan-300/25">
        <div className="mb-5 flex items-center gap-3">
          <img src={APP_ICON} alt="" className="h-12 w-12 rounded-2xl object-cover ring-2 ring-cyan-300/40" />
          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-bold uppercase tracking-[0.28em] text-cyan-300/70">VOCİ Tetris</div>
            <div className="text-base font-black tracking-[0.18em] text-white">{title}</div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-white/10 px-3 py-1.5 text-sm font-bold ring-1 ring-white/15"
          >
            Kapat
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function unlockAch(id: string) {
  try {
    const got = JSON.parse(localStorage.getItem("voci-ach") || "{}");
    if (got[id]) return;
    got[id] = true;
    localStorage.setItem("voci-ach", JSON.stringify(got));
  } catch {
    /* yoksay */
  }
}
