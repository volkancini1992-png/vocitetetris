import type { ActivePiece, Cell, Matrix, PieceKey } from "./tetromino";
import { COLS, ROWS } from "./tetromino";
import { BONUS_PER_LEVEL, type LastPlaced } from "./bonus";

export const SAVE_MAGIC = "VOCI-TETRIS";
export const SAVE_VERSION = 2;

export { BONUS_PER_LEVEL, BONUS_UNLOCK_SCORE } from "./bonus";

const PIECE_KEYS: PieceKey[] = ["I", "O", "T", "S", "Z", "J", "L", "D", "M"];

export type SavePayload = {
  magic: typeof SAVE_MAGIC;
  version: number;
  savedAt: number;
  board: Cell[][];
  current: ActivePiece | null;
  queue: PieceKey[];
  bonusLeft: number;
  lastPlaced: LastPlaced | null;
  score: number;
  lines: number;
  level: number;
  combo: number;
  pieces: number;
};

export const isPieceKey = (x: unknown): x is PieceKey =>
  typeof x === "string" && (PIECE_KEYS as string[]).includes(x);

const isCell = (x: unknown): x is Cell => x === null || x === "G" || isPieceKey(x);

const isMatrix = (m: unknown): m is Matrix => {
  if (!Array.isArray(m) || m.length < 2 || m.length > 4) return false;
  const n = m.length;
  return m.every(
    (row) => Array.isArray(row) && row.length === n && row.every((v) => v === 0 || v === 1)
  );
};

const isActive = (p: unknown): p is ActivePiece => {
  if (!p || typeof p !== "object") return false;
  const o = p as ActivePiece;
  return (
    isPieceKey(o.key) &&
    isMatrix(o.matrix) &&
    Number.isInteger(o.x) &&
    Number.isInteger(o.y) &&
    o.x >= -4 &&
    o.x < COLS + 4 &&
    o.y >= -4 &&
    o.y < ROWS
  );
};

const isLastPlaced = (p: unknown): p is LastPlaced => {
  if (p === null) return true;
  if (!p || typeof p !== "object") return false;
  const o = p as LastPlaced;
  if (!isPieceKey(o.key) || !Array.isArray(o.cells) || o.cells.length < 1 || o.cells.length > 4) {
    return false;
  }
  return o.cells.every(
    (c) =>
      c &&
      Number.isInteger(c.x) &&
      Number.isInteger(c.y) &&
      c.x >= 0 &&
      c.x < COLS &&
      c.y >= 0 &&
      c.y < ROWS
  );
};

export function parseSave(raw: unknown): SavePayload | string {
  if (!raw || typeof raw !== "object") return "Dosya boş veya bozuk";
  const o = raw as Record<string, unknown>;
  if (o.magic !== SAVE_MAGIC) return "Bu bir VOCİ Tetris kayıt dosyası değil";
  if (o.version !== SAVE_VERSION) return `Kayıt sürümü desteklenmiyor (${String(o.version)})`;
  if (!Array.isArray(o.board) || o.board.length !== ROWS) return "Tahta boyutu hatalı";
  if (!o.board.every((row) => Array.isArray(row) && row.length === COLS && row.every(isCell))) {
    return "Tahta içeriği hatalı";
  }
  if (o.current !== null && !isActive(o.current)) return "Aktif blok hatalı";
  if (!Array.isArray(o.queue) || o.queue.length < 1 || o.queue.length > 21 || !o.queue.every(isPieceKey)) {
    return "Blok kuyruğu hatalı";
  }
  if (!isLastPlaced(o.lastPlaced ?? null)) return "Son blok bilgisi hatalı";
  const nums = ["score", "lines", "level", "combo", "pieces", "bonusLeft", "savedAt"] as const;
  for (const k of nums) {
    if (typeof o[k] !== "number" || !Number.isFinite(o[k] as number) || (o[k] as number) < 0) {
      return `Alan hatalı: ${k}`;
    }
  }
  if ((o.level as number) < 1 || (o.level as number) > 99) return "Seviye hatalı";
  if ((o.bonusLeft as number) > BONUS_PER_LEVEL) return "Bonus hakkı hatalı";

  return {
    magic: SAVE_MAGIC,
    version: SAVE_VERSION,
    savedAt: o.savedAt as number,
    board: (o.board as Cell[][]).map((r) => [...r]),
    current: o.current
      ? {
          key: (o.current as ActivePiece).key,
          x: (o.current as ActivePiece).x,
          y: (o.current as ActivePiece).y,
          matrix: (o.current as ActivePiece).matrix.map((r) => [...r]),
        }
      : null,
    queue: [...(o.queue as PieceKey[])],
    bonusLeft: Math.min(BONUS_PER_LEVEL, Math.floor(o.bonusLeft as number)),
    lastPlaced: o.lastPlaced
      ? {
          key: (o.lastPlaced as LastPlaced).key,
          cells: (o.lastPlaced as LastPlaced).cells.map((c) => ({ x: c.x, y: c.y })),
        }
      : null,
    score: Math.floor(o.score as number),
    lines: Math.floor(o.lines as number),
    level: Math.floor(o.level as number),
    combo: Math.floor(o.combo as number),
    pieces: Math.floor(o.pieces as number),
  };
}

export function snapshotSave(s: {
  board: Cell[][];
  current: ActivePiece | null;
  queue: PieceKey[];
  bonusLeft: number;
  lastPlaced: LastPlaced | null;
  score: number;
  lines: number;
  level: number;
  combo: number;
  pieces: number;
}): SavePayload {
  return {
    magic: SAVE_MAGIC,
    version: SAVE_VERSION,
    savedAt: Date.now(),
    board: s.board.map((r) => [...r]),
    current: s.current
      ? {
          key: s.current.key,
          x: s.current.x,
          y: s.current.y,
          matrix: s.current.matrix.map((r) => [...r]),
        }
      : null,
    queue: [...s.queue],
    bonusLeft: s.bonusLeft,
    lastPlaced: s.lastPlaced
      ? { key: s.lastPlaced.key, cells: s.lastPlaced.cells.map((c) => ({ ...c })) }
      : null,
    score: s.score,
    lines: s.lines,
    level: s.level,
    combo: s.combo,
    pieces: s.pieces,
  };
}

const STORE_KEY = "voci-tetris-saves-v2";
const MAX_SAVES = 20;

export type StoredSave = SavePayload & { id: string };

export function listSaves(): StoredSave[] {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as unknown;
    if (!Array.isArray(arr)) return [];
    return arr.filter((x) => x && typeof x === "object" && typeof (x as StoredSave).id === "string") as StoredSave[];
  } catch {
    return [];
  }
}

function writeAll(list: StoredSave[]) {
  localStorage.setItem(STORE_KEY, JSON.stringify(list.slice(0, MAX_SAVES)));
}

export function persistSave(data: SavePayload): StoredSave {
  const entry: StoredSave = { ...data, id: `save_${data.savedAt}_${Math.random().toString(36).slice(2, 8)}` };
  const next = [entry, ...listSaves().filter((s) => s.id !== entry.id)];
  writeAll(next);
  return entry;
}

export function getSave(id: string): StoredSave | null {
  return listSaves().find((s) => s.id === id) ?? null;
}

export function deleteSave(id: string) {
  writeAll(listSaves().filter((s) => s.id !== id));
}
