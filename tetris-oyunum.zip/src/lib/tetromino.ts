export type PieceKey = "I" | "O" | "T" | "S" | "Z" | "J" | "L" | "D" | "M";
export type Matrix = number[][];
export type Cell = PieceKey | "G" | null;

export const COLS = 10;
export const ROWS = 20;

export interface PieceDef {
  key: PieceKey;
  matrix: Matrix;
  spawnY: number;
}

export const PIECES: Record<PieceKey, PieceDef> = {
  I: {
    key: "I",
    spawnY: -1,
    matrix: [
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ],
  },
  O: {
    key: "O",
    spawnY: 0,
    matrix: [
      [1, 1],
      [1, 1],
    ],
  },
  T: {
    key: "T",
    spawnY: 0,
    matrix: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
  },
  S: {
    key: "S",
    spawnY: 0,
    matrix: [
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0],
    ],
  },
  Z: {
    key: "Z",
    spawnY: 0,
    matrix: [
      [1, 1, 0],
      [0, 1, 1],
      [0, 0, 0],
    ],
  },
  J: {
    key: "J",
    spawnY: 0,
    matrix: [
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
  },
  L: {
    key: "L",
    spawnY: 0,
    matrix: [
      [0, 0, 1],
      [1, 1, 1],
      [0, 0, 0],
    ],
  },
  D: {
    key: "D",
    spawnY: 0,
    matrix: [[1]],
  },
  M: {
    key: "M",
    spawnY: 0,
    matrix: [
      [1, 1],
      [0, 0],
    ],
  },
};

/** Tailwind-free renk paleti: her taş için gradient + parlama rengi */
export const COLORS: Record<
  Exclude<Cell, null>,
  { from: string; to: string; glow: string; edge: string }
> = {
  I: { from: "#67e8f9", to: "#0891b2", glow: "#22d3ee", edge: "#a5f3fc" },
  O: { from: "#fde68a", to: "#d97706", glow: "#fbbf24", edge: "#fef3c7" },
  T: { from: "#e9a8fd", to: "#8b21c9", glow: "#c026d3", edge: "#f5d0fe" },
  S: { from: "#86efac", to: "#15803d", glow: "#22c55e", edge: "#bbf7d0" },
  Z: { from: "#fca5a5", to: "#b91c1c", glow: "#ef4444", edge: "#fecaca" },
  J: { from: "#93c5fd", to: "#1d4ed8", glow: "#3b82f6", edge: "#bfdbfe" },
  L: { from: "#fdba74", to: "#c2410c", glow: "#f97316", edge: "#fed7aa" },
  D: { from: "#f9a8d4", to: "#db2777", glow: "#ec4899", edge: "#fbcfe8" },
  M: { from: "#99f6e4", to: "#0f766e", glow: "#14b8a6", edge: "#ccfbf1" },
  G: { from: "#94a3b8", to: "#334155", glow: "#64748b", edge: "#cbd5e1" },
};

export interface ActivePiece {
  key: PieceKey;
  matrix: Matrix;
  x: number;
  y: number;
}

export const createBoard = (): Cell[][] =>
  Array.from({ length: ROWS }, () => Array<Cell>(COLS).fill(null));

export const rotate = (matrix: Matrix, dir: 1 | -1): Matrix => {
  const n = matrix.length;
  const out: Matrix = Array.from({ length: n }, () => Array<number>(n).fill(0));
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      if (dir === 1) out[x][n - 1 - y] = matrix[y][x];
      else out[n - 1 - x][y] = matrix[y][x];
    }
  }
  return out;
};

export const collides = (board: Cell[][], piece: ActivePiece): boolean => {
  const { matrix, x: px, y: py } = piece;
  for (let y = 0; y < matrix.length; y++) {
    for (let x = 0; x < matrix[y].length; x++) {
      if (!matrix[y][x]) continue;
      const bx = px + x;
      const by = py + y;
      if (bx < 0 || bx >= COLS || by >= ROWS) return true;
      if (by >= 0 && board[by][bx]) return true;
    }
  }
  return false;
};

export const spawnPiece = (key: PieceKey): ActivePiece => {
  const def = PIECES[key];
  const width = def.matrix.length;
  return {
    key,
    matrix: def.matrix.map((r) => [...r]),
    x: Math.floor((COLS - width) / 2),
    y: def.spawnY,
  };
};

/** 7-bag rastgeleleştirici */
export const newBag = (): PieceKey[] => {
  const bag: PieceKey[] = ["I", "O", "T", "S", "Z", "J", "L", "D", "M"];
  for (let i = bag.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return bag;
};

/** Duvar itmeleri (basitleştirilmiş SRS) */
export const KICKS = [0, -1, 1, -2, 2];

export const dropDistance = (board: Cell[][], piece: ActivePiece): number => {
  let d = 0;
  while (!collides(board, { ...piece, y: piece.y + d + 1 })) d++;
  return d;
};

/** Sonsuz level: asemptotik hız. 1 kolay, 100 hızlı ama oynanabilir, asla < 72ms */
export const speedForLevel = (level: number): number => {
  const L = Math.max(1, level);
  const base = 940;
  const min = 130;
  return Math.round(min + (base - min) / (1 + 0.09 * (L - 1)));
};

export const lockDelayForLevel = (level: number): number => {
  const L = Math.max(1, level);
  return Math.round(150 + 370 / (1 + 0.11 * (L - 1)));
};

const rng = (seed: number) => {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
};

/** Level 5+ altta çözülebilir çelik. Spawn bölgesi her zaman boş. */
export const generateLevelBoard = (level: number): Cell[][] => {
  const empty = createBoard();
  if (level < 5) return empty;

  const paint = (board: Cell[][], seed: number) => {
    const rnd = rng(seed);
    const band = level < 15 ? 1 : level < 30 ? 2 : 2;
    for (let i = 0; i < band; i++) {
      const y = ROWS - 1 - i;
      const emptyCount = 4 + Math.floor(rnd() * 3);
      const idxs = Array.from({ length: COLS }, (_, x) => x);
      for (let a = idxs.length - 1; a > 0; a--) {
        const b = Math.floor(rnd() * (a + 1));
        [idxs[a], idxs[b]] = [idxs[b], idxs[a]];
      }
      const steel = idxs.slice(0, COLS - emptyCount);
      for (const x of steel) board[y][x] = "G";
    }
  };

  const ok = (board: Cell[][]) => {
    for (let y = 0; y < 6; y++) if (board[y].some((c) => c)) return false;
    for (let y = 0; y < ROWS; y++) {
      const steel = board[y].filter((c) => c === "G").length;
      if (steel === COLS) return false;
      if (steel > 0 && COLS - steel < 2) return false;
    }
    const bottomEmpty = board[ROWS - 1].filter((c) => c === null).length;
    return bottomEmpty >= 3;
  };

  for (let attempt = 0; attempt < 18; attempt++) {
    const board = createBoard();
    paint(board, level * 7919 + attempt * 104729);
    if (ok(board)) return board;
  }
  const fb = createBoard();
  for (let x = 0; x < COLS; x++) if (x % 3 !== 1) fb[ROWS - 1][x] = "G";
  return fb;
};

export const LINE_SCORES = [0, 100, 300, 500, 800];

export const trimMatrix = (matrix: Matrix) => {
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;
  matrix.forEach((row, y) =>
    row.forEach((v, x) => {
      if (v) {
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
      }
    })
  );
  if (minX === Infinity) return [] as Matrix;
  const out: Matrix = [];
  for (let y = minY; y <= maxY; y++) out.push(matrix[y].slice(minX, maxX + 1));
  return out;
};
