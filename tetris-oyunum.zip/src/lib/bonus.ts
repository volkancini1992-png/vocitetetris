import type { ActivePiece, Cell, PieceKey } from "./tetromino";
import { COLS, ROWS } from "./tetromino";

export const BONUS_UNLOCK_SCORE = 800;
export const BONUS_PER_LEVEL = 3;

export type CellPos = { x: number; y: number };

export type LastPlaced = {
  key: PieceKey;
  cells: CellPos[];
};

export type Relocating = {
  key: PieceKey;
  /** Tutulan hücreye göre göreli parçalar (tutulan hücre = 0,0) */
  rel: CellPos[];
  /** Tahtadan kaldırılan orijinal hücreler */
  from: CellPos[];
  /** İmlecin bulunduğu tahta hücresi */
  hover: CellPos | null;
  /** İlk tıklama: bırakmadan elde tutmaya geç */
  justPicked: boolean;
};

export const posKey = (c: CellPos) => `${c.x},${c.y}`;

export function pieceCells(p: ActivePiece): CellPos[] {
  const out: CellPos[] = [];
  for (let y = 0; y < p.matrix.length; y++) {
    for (let x = 0; x < p.matrix[y].length; x++) {
      if (p.matrix[y][x]) out.push({ x: p.x + x, y: p.y + y });
    }
  }
  return out;
}

export function cellsEqual(a: CellPos[], b: CellPos[]): boolean {
  if (a.length !== b.length) return false;
  const s = new Set(a.map(posKey));
  return b.every((c) => s.has(posKey(c)));
}

export function lastPlacedIntact(board: Cell[][], lp: LastPlaced): boolean {
  return lp.cells.every(
    (c) => c.x >= 0 && c.x < COLS && c.y >= 0 && c.y < ROWS && board[c.y][c.x] === lp.key
  );
}

/** Satır silinince son bloğu güncelle; parçalandıysa null. */
export function remapAfterClear(cells: CellPos[], cleared: number[]): CellPos[] | null {
  const set = new Set(cleared);
  if (cells.some((c) => set.has(c.y))) return null;
  return cells.map((c) => ({
    x: c.x,
    y: c.y + cleared.filter((r) => r > c.y).length,
  }));
}

export function remapAfterGarbage(cells: CellPos[]): CellPos[] | null {
  const next = cells.map((c) => ({ x: c.x, y: c.y - 1 }));
  if (next.some((c) => c.y < 0)) return null;
  return next;
}

export function worldCells(rel: CellPos[], hover: CellPos): CellPos[] {
  return rel.map((c) => ({ x: c.x + hover.x, y: c.y + hover.y }));
}

function overlapsCurrent(cells: CellPos[], current: ActivePiece | null): boolean {
  if (!current) return false;
  const falling = new Set(pieceCells(current).map(posKey));
  return cells.some((c) => falling.has(posKey(c)));
}

/** Hedef boş, tahta içinde ve yere / başka bloğa oturuyor mu? */
export function placementValid(
  board: Cell[][],
  cells: CellPos[],
  current: ActivePiece | null
): boolean {
  if (cells.length === 0) return false;
  for (const c of cells) {
    if (c.x < 0 || c.x >= COLS || c.y < 0 || c.y >= ROWS) return false;
    if (board[c.y][c.x]) return false;
  }
  if (overlapsCurrent(cells, current)) return false;

  const self = new Set(cells.map(posKey));
  const canFall = cells.every((c) => {
    const ny = c.y + 1;
    if (ny >= ROWS) return false;
    if (self.has(`${c.x},${ny}`)) return true;
    return board[ny][c.x] === null;
  });
  return !canFall;
}

export function writeCells(board: Cell[][], cells: CellPos[], key: PieceKey | null) {
  for (const c of cells) {
    if (c.y >= 0 && c.y < ROWS && c.x >= 0 && c.x < COLS) board[c.y][c.x] = key;
  }
}

export function isLastCell(lp: LastPlaced | null, x: number, y: number): boolean {
  return !!lp && lp.cells.some((c) => c.x === x && c.y === y);
}

export function isActiveCell(piece: ActivePiece | null, x: number, y: number): boolean {
  return !!piece && pieceCells(piece).some((c) => c.x === x && c.y === y);
}
