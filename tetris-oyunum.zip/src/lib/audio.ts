/**
 * Web Audio API ile sentezlenen çoklu arkaplan müziği + ses efektleri.
 * Seviye yükseldikçe yavaş parçalardan hızlı parçalara otomatik geçilir.
 */

type Note = [string | null, number];

export interface Track {
  id: number;
  name: string;
  mood: string;
  tempo: number;
  minLevel: number;
  lead: OscillatorType;
  lead2: OscillatorType;
  cutoff: number;
  leadGain: number;
  drums: "soft" | "normal" | "hard";
  melody: Note[];
  bass: string[];
}

const NOTE_INDEX: Record<string, number> = {
  C: 0, "C#": 1, Db: 1, D: 2, "D#": 3, Eb: 3, E: 4, F: 5, "F#": 6,
  Gb: 6, G: 7, "G#": 8, Ab: 8, A: 9, "A#": 10, Bb: 10, B: 11,
};

const freq = (note: string): number => {
  const m = /^([A-G][#b]?)(-?\d)$/.exec(note);
  if (!m) return 440;
  const semitone = NOTE_INDEX[m[1]] ?? 9;
  const octave = parseInt(m[2], 10);
  return 440 * Math.pow(2, ((octave + 1) * 12 + semitone - 69) / 12);
};

// ───────────────────────────────────────────── 1. KAR TANESİ (sakin)
const T1_MELODY: Note[] = [
  ["A4", 2], ["C5", 1], ["E5", 1], ["D5", 2], ["C5", 1], ["B4", 1],
  ["A4", 2], ["G4", 1], ["A4", 1], ["C5", 3], [null, 1],
  ["F4", 2], ["A4", 1], ["C5", 1], ["E5", 2], ["D5", 2],
  ["G4", 2], ["B4", 1], ["D5", 1], ["C5", 3], [null, 1],
  ["E5", 2], ["D5", 1], ["C5", 1], ["B4", 2], ["A4", 2],
  ["C5", 2], ["B4", 1], ["A4", 1], ["G#4", 3], [null, 1],
  ["A4", 1], ["B4", 1], ["C5", 1], ["D5", 1], ["E5", 2], ["A5", 2],
  ["G5", 2], ["E5", 2], ["A4", 3], [null, 1],
];
const T1_BASS = ["A2", "A2", "F2", "C3", "F2", "G2", "C3", "E2", "A2", "F2", "E2", "A2"];

// ───────────────────────────────────────────── 2. KOROBEINIKI (klasik)
const T2_MELODY: Note[] = [
  ["E5", 1], ["B4", 0.5], ["C5", 0.5], ["D5", 1], ["C5", 0.5], ["B4", 0.5],
  ["A4", 1], ["A4", 0.5], ["C5", 0.5], ["E5", 1], ["D5", 0.5], ["C5", 0.5],
  ["B4", 1.5], ["C5", 0.5], ["D5", 1], ["E5", 1],
  ["C5", 1], ["A4", 1], ["A4", 1], [null, 1],
  [null, 0.5], ["D5", 1], ["F5", 0.5], ["A5", 1], ["G5", 0.5], ["F5", 0.5],
  ["E5", 1.5], ["C5", 0.5], ["E5", 1], ["D5", 0.5], ["C5", 0.5],
  ["B4", 1], ["B4", 0.5], ["C5", 0.5], ["D5", 1], ["E5", 1],
  ["C5", 1], ["A4", 1], ["A4", 1], [null, 1],
  ["E5", 2], ["C5", 2], ["D5", 2], ["B4", 2],
  ["C5", 2], ["A4", 2], ["G#4", 2], ["B4", 2],
  ["E5", 2], ["C5", 2], ["D5", 2], ["B4", 2],
  ["C5", 1], ["E5", 1], ["A5", 2], ["G#5", 2], [null, 2],
];
const T2_BASS = ["E2", "A2", "E2", "A2", "D2", "A2", "B2", "E2", "A2", "F2", "E2", "A2"];

// ───────────────────────────────────────────── 3. KALİNKA ATEŞİ (hareketli)
const T3_MELODY: Note[] = [
  ["A4", 0.5], ["A4", 0.5], ["B4", 0.5], ["C5", 0.5], ["A4", 1], ["A4", 1],
  ["C5", 0.5], ["C5", 0.5], ["D5", 0.5], ["E5", 0.5], ["C5", 1], ["C5", 1],
  ["E5", 0.5], ["E5", 0.5], ["F5", 0.5], ["G5", 0.5], ["E5", 1], ["C5", 1],
  ["B4", 0.5], ["C5", 0.5], ["D5", 0.5], ["B4", 0.5], ["A4", 2],
  ["E5", 0.5], ["D5", 0.5], ["C5", 0.5], ["B4", 0.5], ["A4", 1], ["E5", 1],
  ["D5", 0.5], ["C5", 0.5], ["B4", 0.5], ["A4", 0.5], ["G#4", 1], ["B4", 1],
  ["A4", 0.5], ["B4", 0.5], ["C5", 0.5], ["D5", 0.5], ["E5", 1], ["A5", 1],
  ["G5", 0.5], ["F5", 0.5], ["E5", 0.5], ["D5", 0.5], ["C5", 1], ["A4", 1],
  ["A5", 0.5], ["G5", 0.5], ["A5", 0.5], ["G5", 0.5], ["E5", 1], ["C5", 1],
  ["D5", 0.5], ["E5", 0.5], ["F5", 0.5], ["E5", 0.5], ["D5", 1], ["B4", 1],
  ["C5", 0.5], ["D5", 0.5], ["E5", 0.5], ["C5", 0.5], ["A4", 2], [null, 2],
];
const T3_BASS = ["A2", "A2", "C3", "C3", "E2", "E2", "A2", "A2", "D2", "D2", "E2", "A2"];

// ───────────────────────────────────────────── 4. NEON FIRTINASI (hızlı)
const T4_MELODY: Note[] = [
  ["A4", 0.25], ["C5", 0.25], ["E5", 0.25], ["A5", 0.25],
  ["E5", 0.25], ["C5", 0.25], ["E5", 0.25], ["A5", 0.25],
  ["G4", 0.25], ["B4", 0.25], ["D5", 0.25], ["G5", 0.25],
  ["D5", 0.25], ["B4", 0.25], ["D5", 0.25], ["G5", 0.25],
  ["F4", 0.25], ["A4", 0.25], ["C5", 0.25], ["F5", 0.25],
  ["C5", 0.25], ["A4", 0.25], ["C5", 0.25], ["F5", 0.25],
  ["E4", 0.25], ["G#4", 0.25], ["B4", 0.25], ["E5", 0.25],
  ["B4", 0.25], ["G#4", 0.25], ["B4", 0.25], ["E5", 0.25],
  ["A5", 0.5], ["G5", 0.5], ["E5", 0.5], ["C5", 0.5],
  ["D5", 0.5], ["E5", 0.5], ["F5", 1],
  ["E5", 0.5], ["D5", 0.5], ["C5", 0.5], ["B4", 0.5], ["A4", 2],
  ["C5", 0.25], ["E5", 0.25], ["A5", 0.25], ["C6", 0.25],
  ["A5", 0.25], ["E5", 0.25], ["C5", 0.25], ["A4", 0.25],
  ["B4", 0.25], ["D5", 0.25], ["G5", 0.25], ["B5", 0.25],
  ["G5", 0.25], ["D5", 0.25], ["B4", 0.25], ["G4", 0.25],
  ["A4", 0.5], ["E5", 0.5], ["A5", 1], ["G#5", 1], ["A5", 1],
];
const T4_BASS = ["A2", "G2", "F2", "E2", "A2", "F2", "E2", "E2", "A2", "G2", "A2", "E2"];

// ───────────────────────────────────────────── 5. HİPERUZAY (çılgın)
const T5_MELODY: Note[] = [
  ["A5", 0.25], ["G#5", 0.25], ["A5", 0.25], ["E5", 0.25],
  ["A5", 0.25], ["G#5", 0.25], ["A5", 0.25], ["C6", 0.25],
  ["B5", 0.25], ["A5", 0.25], ["G5", 0.25], ["F5", 0.25],
  ["E5", 0.25], ["D5", 0.25], ["C5", 0.25], ["B4", 0.25],
  ["A4", 0.25], ["B4", 0.25], ["C5", 0.25], ["D5", 0.25],
  ["E5", 0.25], ["F5", 0.25], ["G5", 0.25], ["A5", 0.25],
  ["A#5", 0.25], ["A5", 0.25], ["G#5", 0.25], ["G5", 0.25],
  ["F#5", 0.25], ["F5", 0.25], ["E5", 0.25], ["D#5", 0.25],
  ["E5", 0.5], ["B4", 0.5], ["E5", 0.5], ["G5", 0.5],
  ["A5", 0.5], ["G5", 0.5], ["E5", 0.5], ["D5", 0.5],
  ["C5", 0.25], ["E5", 0.25], ["A5", 0.25], ["E5", 0.25],
  ["C5", 0.25], ["E5", 0.25], ["A5", 0.25], ["E5", 0.25],
  ["D5", 0.25], ["F5", 0.25], ["A5", 0.25], ["F5", 0.25],
  ["E5", 0.25], ["G5", 0.25], ["B5", 0.25], ["G5", 0.25],
  ["A5", 1], ["E5", 0.5], ["A5", 0.5], ["C6", 2],
];
const T5_BASS = ["A2", "A2", "F2", "F2", "G2", "G2", "E2", "E2", "A2", "C3", "E2", "A2"];

export const TRACKS: Track[] = [
  {
    id: 0, name: "Kar Tanesi", mood: "Sakin", tempo: 92, minLevel: 1,
    lead: "sine", lead2: "triangle", cutoff: 1800, leadGain: 0.3, drums: "soft",
    melody: T1_MELODY, bass: T1_BASS,
  },
  {
    id: 1, name: "Korobeiniki", mood: "Klasik", tempo: 140, minLevel: 3,
    lead: "square", lead2: "triangle", cutoff: 2600, leadGain: 0.32, drums: "normal",
    melody: T2_MELODY, bass: T2_BASS,
  },
  {
    id: 2, name: "Kalinka Ateşi", mood: "Hareketli", tempo: 172, minLevel: 5,
    lead: "square", lead2: "sawtooth", cutoff: 3000, leadGain: 0.3, drums: "normal",
    melody: T3_MELODY, bass: T3_BASS,
  },
  {
    id: 3, name: "Neon Fırtınası", mood: "Hızlı", tempo: 196, minLevel: 8,
    lead: "sawtooth", lead2: "square", cutoff: 3400, leadGain: 0.27, drums: "hard",
    melody: T4_MELODY, bass: T4_BASS,
  },
  {
    id: 4, name: "Hiperuzay", mood: "Çılgın", tempo: 224, minLevel: 12,
    lead: "square", lead2: "sawtooth", cutoff: 3800, leadGain: 0.26, drums: "hard",
    melody: T5_MELODY, bass: T5_BASS,
  },
];

export const trackForLevel = (level: number): number => {
  let idx = 0;
  TRACKS.forEach((t, i) => {
    if (level >= t.minLevel) idx = i;
  });
  return idx;
};

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private timer: number | null = null;

  private noteIndex = 0;
  private nextNoteTime = 0;
  private beatCounter = 0;
  private tempo = TRACKS[0].tempo;

  trackIndex = 0;
  manualTrack: number | null = null;
  musicOn = true;
  sfxOn = true;
  running = false;

  private listeners = new Set<(t: Track) => void>();

  get track(): Track {
    return TRACKS[this.trackIndex];
  }

  onTrackChange(cb: (t: Track) => void) {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private emit() {
    this.listeners.forEach((cb) => cb(this.track));
  }

  private ensure(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (!Ctor) return null;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.85;
      this.master.connect(this.ctx.destination);

      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.ratio.value = 6;
      comp.connect(this.master);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.musicOn ? 1 : 0;
      this.musicGain.connect(comp);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.sfxOn ? 0.5 : 0;
      this.sfxGain.connect(comp);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  unlock() {
    this.ensure();
  }

  /** Seviyeye göre parça ve tempo ayarı. Parça değiştiyse Track döner. */
  setLevel(level: number): Track | null {
    const target = this.manualTrack ?? trackForLevel(level);
    const t = TRACKS[target];
    this.tempo = Math.min(t.tempo + (level - t.minLevel) * 3, t.tempo + 38);
    if (target !== this.trackIndex) {
      this.trackIndex = target;
      this.restartTrack();
      this.emit();
      return t;
    }
    return null;
  }

  /** Manuel parça seçimi (null = otomatik / seviyeye bağlı) */
  setManualTrack(idx: number | null, level: number) {
    this.manualTrack = idx;
    const target = idx ?? trackForLevel(level);
    const t = TRACKS[target];
    this.tempo = Math.min(t.tempo + (level - t.minLevel) * 3, t.tempo + 38);
    if (target !== this.trackIndex) {
      this.trackIndex = target;
      this.restartTrack();
    }
    this.emit();
  }

  private restartTrack() {
    const ctx = this.ctx;
    this.noteIndex = 0;
    this.beatCounter = 0;
    if (ctx && this.musicGain && this.running) {
      const g = this.musicGain.gain;
      const now = ctx.currentTime;
      g.cancelScheduledValues(now);
      g.setValueAtTime(g.value, now);
      g.linearRampToValueAtTime(0.0001, now + 0.18);
      g.linearRampToValueAtTime(this.musicOn ? 1 : 0, now + 0.75);
      this.nextNoteTime = now + 0.35;
    }
  }

  setMusic(on: boolean) {
    this.musicOn = on;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(on ? 1 : 0, this.ctx.currentTime, 0.05);
    }
  }

  setSfx(on: boolean) {
    this.sfxOn = on;
    if (this.sfxGain) this.sfxGain.gain.value = on ? 0.5 : 0;
  }

  setVolume(v: number) {
    if (this.master && this.ctx)
      this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.03);
  }

  // ---------- müzik zamanlayıcı ----------
  startMusic(fromStart = false) {
    const ctx = this.ensure();
    if (!ctx || this.running) return;
    if (fromStart) {
      this.noteIndex = 0;
      this.beatCounter = 0;
    }
    this.running = true;
    this.nextNoteTime = ctx.currentTime + 0.08;
    this.timer = window.setInterval(() => this.scheduler(), 25);
  }

  stopMusic() {
    this.running = false;
    if (this.timer !== null) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
  }

  private scheduler() {
    const ctx = this.ctx;
    if (!ctx) return;
    const track = this.track;
    const beatDur = 60 / this.tempo;
    while (this.nextNoteTime < ctx.currentTime + 0.15) {
      const item = track.melody[this.noteIndex % track.melody.length];
      const [note, beats] = item;
      const dur = beats * beatDur;
      if (note) this.playLead(freq(note), this.nextNoteTime, dur, track);
      this.scheduleRhythm(this.nextNoteTime, beats, beatDur, track);
      this.nextNoteTime += dur;
      this.noteIndex = (this.noteIndex + 1) % track.melody.length;
      if (this.noteIndex === 0) this.beatCounter = 0;
    }
  }

  private scheduleRhythm(time: number, beats: number, beatDur: number, track: Track) {
    const start = this.beatCounter;
    const end = start + beats;
    for (let b = Math.ceil(start - 1e-6); b < end - 1e-6; b++) {
      const t = time + (b - start) * beatDur;
      const measure = Math.floor(b / 4) % track.bass.length;
      const beatInMeasure = ((b % 4) + 4) % 4;
      const root = freq(track.bass[measure]);
      const f = beatInMeasure % 2 === 0 ? root : root * 1.5;
      this.playBass(f, t, beatDur * 0.85, track);
      if (track.drums !== "soft") this.playHat(t + beatDur * 0.5, 0.02, track);
      if (track.drums === "hard" && beatInMeasure % 2 === 0) this.playKick(t);
    }
    this.beatCounter = end;
  }

  private playLead(f: number, time: number, dur: number, track: Track) {
    const ctx = this.ctx;
    const out = this.musicGain;
    if (!ctx || !out) return;
    const osc = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = track.cutoff;

    osc.type = track.lead;
    osc.frequency.value = f;
    osc2.type = track.lead2;
    osc2.frequency.value = f * 2.002;

    const d = Math.max(0.05, dur * 0.92);
    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.exponentialRampToValueAtTime(track.leadGain, time + 0.012);
    gain.gain.exponentialRampToValueAtTime(track.leadGain * 0.45, time + d * 0.5);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + d);

    osc.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc2.start(time);
    osc.stop(time + d + 0.05);
    osc2.stop(time + d + 0.05);
  }

  private playBass(f: number, time: number, dur: number, track: Track) {
    const ctx = this.ctx;
    const out = this.musicGain;
    if (!ctx || !out) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = track.drums === "soft" ? "sine" : "sawtooth";
    osc.frequency.value = f;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(track.drums === "soft" ? 500 : 900, time);
    filter.frequency.exponentialRampToValueAtTime(240, time + dur);
    const vol = track.drums === "soft" ? 0.22 : 0.28;
    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.exponentialRampToValueAtTime(vol, time + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + dur);
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc.stop(time + dur + 0.03);
  }

  private playKick(time: number) {
    const ctx = this.ctx;
    const out = this.musicGain;
    if (!ctx || !out) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(140, time);
    osc.frequency.exponentialRampToValueAtTime(45, time + 0.12);
    gain.gain.setValueAtTime(0.32, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.16);
    osc.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc.stop(time + 0.2);
  }

  private playHat(time: number, dur: number, track: Track) {
    const ctx = this.ctx;
    const out = this.musicGain;
    if (!ctx || !out) return;
    const size = Math.floor(ctx.sampleRate * 0.05);
    const buffer = ctx.createBuffer(1, size, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < size; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const hp = ctx.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 7000;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(track.drums === "hard" ? 0.085 : 0.055, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + dur + 0.03);
    src.connect(hp);
    hp.connect(gain);
    gain.connect(out);
    src.start(time);
    src.stop(time + 0.06);
  }

  // ---------- ses efektleri ----------
  private blip(f: number, dur: number, type: OscillatorType = "square", vol = 0.3, slideTo?: number) {
    const ctx = this.ensure();
    const out = this.sfxGain;
    if (!ctx || !out || !this.sfxOn) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(gain);
    gain.connect(out);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  private sequence(notes: number[], step: number, type: OscillatorType, vol: number, hold: number) {
    const ctx = this.ensure();
    const out = this.sfxGain;
    if (!ctx || !out || !this.sfxOn) return;
    notes.forEach((f, i) => {
      const t = ctx.currentTime + i * step;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.value = f;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(vol, t + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + hold);
      osc.connect(gain);
      gain.connect(out);
      osc.start(t);
      osc.stop(t + hold + 0.05);
    });
  }

  move() { this.blip(300, 0.05, "square", 0.16); }
  rotate() { this.blip(520, 0.07, "triangle", 0.24, 760); }
  lock() { this.blip(150, 0.1, "sawtooth", 0.22, 70); }
  hardDrop() { this.blip(420, 0.12, "square", 0.26, 90); }
  hold() { this.blip(660, 0.09, "sine", 0.24, 880); }
  ui() { this.blip(880, 0.05, "sine", 0.18); }

  clear(lines: number) {
    const base = [523.25, 659.25, 783.99, 1046.5];
    const count = lines >= 4 ? 6 : 3 + lines;
    const notes = Array.from({ length: count }, (_, i) => base[i % 4] * (lines >= 4 ? 1.5 : 1));
    this.sequence(notes, 0.055, lines >= 4 ? "square" : "triangle", 0.3, 0.16);
  }

  levelUp() {
    this.sequence([440, 554.37, 659.25, 880], 0.09, "square", 0.3, 0.25);
  }

  /** Rekor kırıldı fanfarı */
  record() {
    this.sequence(
      [523.25, 659.25, 783.99, 1046.5, 1318.5, 1046.5, 1318.5, 1567.98],
      0.1, "square", 0.32, 0.32
    );
  }

  gameOver() {
    this.sequence([523.25, 415.3, 349.23, 261.63, 196], 0.14, "sawtooth", 0.28, 0.4);
  }

  boom() {
    const ctx = this.ensure();
    const out = this.sfxGain;
    if (!ctx || !out || !this.sfxOn) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(180, t);
    osc.frequency.exponentialRampToValueAtTime(40, t + 0.45);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.45, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    osc.connect(g);
    g.connect(out);
    osc.start(t);
    osc.stop(t + 0.55);
    const n = ctx.createBuffer(1, ctx.sampleRate * 0.35, ctx.sampleRate);
    const d = n.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
    const src = ctx.createBufferSource();
    src.buffer = n;
    const ng = ctx.createGain();
    ng.gain.value = 0.35;
    src.connect(ng);
    ng.connect(out);
    src.start(t);
  }
}

export const audio = new AudioEngine();
