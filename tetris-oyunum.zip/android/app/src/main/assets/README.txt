BURAYA dist/index.html KOPYALANMALI

Antigravity / Android Studio:
1) Proje kökünde: npm run build
2) dist/index.html dosyasını bu klasöre index.html adıyla kopyala:
   android/app/src/main/assets/index.html
3) Android Studio ile android klasörünü aç veya:
   cd android && ./gradlew assembleDebug
4) APK:
   android/app/build/outputs/apk/debug/app-debug.apk
